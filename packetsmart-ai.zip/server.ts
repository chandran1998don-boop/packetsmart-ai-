import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json());

// Initialize Gemini with telemetry User-Agent header
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

/**
 * Endpoint: Parse natural language or receipt text into a structured transaction
 */
app.post('/api/ai/parse-transaction', async (req, res) => {
  try {
    const { input, availablePackets } = req.body;
    if (!input || typeof input !== 'string') {
      return res.status(400).json({ error: 'Text input is required' });
    }

    if (!ai) {
      // Fallback heuristic parser if API key is absent
      const amountMatch = input.match(/\$?\s*(\d+(?:\.\d{1,2})?)/);
      const amount = amountMatch ? parseFloat(amountMatch[1]) : 25.00;
      const isIncome = /earned|paycheck|salary|deposit|refund|income|bonus/i.test(input);
      const title = input.replace(/\$?\d+(\.\d{1,2})?/g, '').trim().slice(0, 40) || (isIncome ? 'Income Entry' : 'Expense Entry');
      return res.json({
        title,
        amount,
        type: isIncome ? 'income' : 'expense',
        packetId: availablePackets?.[0]?.id || 'groceries',
        packetName: availablePackets?.[0]?.name || 'Groceries & Pantry',
        category: isIncome ? 'Income' : 'General',
        merchant: 'Self',
        date: new Date().toISOString().split('T')[0],
        notes: `Parsed from: "${input}"`,
        confidence: 0.75,
      });
    }

    const packetsListStr = Array.isArray(availablePackets)
      ? availablePackets.map((p: any) => `ID: "${p.id}", Name: "${p.name}", Category: "${p.category || p.name}"`).join('\n')
      : 'Housing (housing), Groceries (groceries), Dining (dining), Transit (transit), Entertainment (entertainment), Health (health), Savings (savings)';

    const prompt = `You are a financial entity extractor for an envelope budget app.
Analyze this user expense or income text:
"${input}"

Today's current date is ${new Date().toISOString().split('T')[0]}.

Available Envelopes/Packets:
${packetsListStr}

Extract the transaction into structured JSON. If the user expresses income (paycheck, freelance, refund, bonus), set type to "income". Otherwise set type to "expense".
Choose the most accurate packetId from the available list. If none matches exactly, pick the closest one.
Extract the merchant name if identifiable (e.g. "Trader Joe's", "Uber", "Employer").`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: 'Short clean title of the transaction (e.g. Weekly Groceries)' },
            amount: { type: Type.NUMBER, description: 'Numeric amount (positive number, e.g. 45.50)' },
            type: { type: Type.STRING, description: '"expense" or "income"' },
            packetId: { type: Type.STRING, description: 'The exact ID of the matching packet from available packets' },
            packetName: { type: Type.STRING, description: 'The human-readable name of the envelope packet' },
            category: { type: Type.STRING, description: 'General category name' },
            merchant: { type: Type.STRING, description: 'Merchant or source organization name' },
            date: { type: Type.STRING, description: 'Date in YYYY-MM-DD format. Default to today if unspecified' },
            notes: { type: Type.STRING, description: 'Short note or context' },
            confidence: { type: Type.NUMBER, description: 'Confidence between 0 and 1' },
          },
          required: ['title', 'amount', 'type', 'packetId', 'packetName', 'category', 'date'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error parsing transaction with Gemini:', error);
    return res.status(500).json({ error: error.message || 'Failed to parse transaction' });
  }
});

/**
 * Endpoint: Comprehensive AI Budget Audit & Health Check
 */
app.post('/api/ai/audit', async (req, res) => {
  try {
    const { packets, monthlyIncome, currentSpend, transactions, currency = '$' } = req.body;

    if (!ai) {
      // Heuristic fallback response
      const totalBudgeted = (packets || []).reduce((acc: number, p: any) => acc + (p.allocated || 0), 0);
      const savingsRate = monthlyIncome > 0 ? Math.max(0, Math.round(((monthlyIncome - currentSpend) / monthlyIncome) * 100)) : 18;
      return res.json({
        overallHealthScore: savingsRate > 20 ? 86 : 72,
        healthRating: savingsRate > 20 ? 'Good' : 'Caution',
        summaryHeadline: `You're tracking at a ${savingsRate}% savings rate this cycle.`,
        keyInsights: [
          `Total income allocated: ${currency}${totalBudgeted.toLocaleString()} out of ${currency}${monthlyIncome.toLocaleString()}.`,
          'Dining and Entertainment packets are trending ahead of your month-to-date target.',
          'Housing fixed obligations remain stable and on-target.',
        ],
        monthlySavingsProjected: Math.max(0, monthlyIncome - currentSpend),
        savingsRatePercent: savingsRate,
        leakAlerts: [
          {
            packetName: 'Dining Out & Cafes',
            title: 'High Micro-Transaction Frequency',
            description: 'Multiple daily cafe visits detected averaging $6.50 each.',
            estimatedMonthlyLeak: 65,
          },
        ],
        recommendations: [
          {
            title: 'Shift $40 from Entertainment to Groceries',
            category: 'Packet Rebalance',
            impact: 'Prevents grocery envelope overdraft before pay period',
            actionPlan: 'Reallocate surplus unspent leisure budget to cushion essentials.',
            priority: 'high',
          },
          {
            title: 'Automate Wealth Packet Transfer',
            category: 'Savings',
            impact: `Guarantees ${currency}450 saved on payday`,
            actionPlan: 'Move money to high-yield savings on the 1st of each month.',
            priority: 'medium',
          },
        ],
        cashflowForecast: 'At the current burn rate, you will conclude the month with a comfortable surplus.',
      });
    }

    const auditPrompt = `You are PacketSmart AI, an elite behavioral financial analyst.
Analyze the user's envelope budget state:
- Currency: ${currency}
- Monthly Income: ${monthlyIncome}
- Total Spend to date: ${currentSpend}
- Packets/Envelopes status:
${JSON.stringify(packets, null, 2)}
- Recent transactions sample:
${JSON.stringify((transactions || []).slice(0, 15), null, 2)}

Provide a deep, realistic, compassionate and numbers-driven audit.
Calculate an honest overallHealthScore (0-100), healthRating ("Excellent" | "Good" | "Caution" | "Action Needed"), summary headline, key data-backed insights, potential budget leak alerts with dollar figures, prioritized recommendations, and cashflow forecast.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: auditPrompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overallHealthScore: { type: Type.INTEGER, description: 'Score between 0 and 100' },
            healthRating: { type: Type.STRING, description: '"Excellent", "Good", "Caution", or "Action Needed"' },
            summaryHeadline: { type: Type.STRING, description: 'One clear, compelling takeaway sentence' },
            keyInsights: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3-4 quantitative observations from their spending'
            },
            monthlySavingsProjected: { type: Type.NUMBER, description: 'Projected net savings this month' },
            savingsRatePercent: { type: Type.NUMBER, description: 'Savings rate as percentage (e.g. 22.5)' },
            leakAlerts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  packetName: { type: Type.STRING },
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  estimatedMonthlyLeak: { type: Type.NUMBER },
                },
                required: ['packetName', 'title', 'description', 'estimatedMonthlyLeak'],
              },
            },
            recommendations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  category: { type: Type.STRING },
                  impact: { type: Type.STRING },
                  actionPlan: { type: Type.STRING },
                  priority: { type: Type.STRING },
                },
                required: ['title', 'category', 'impact', 'actionPlan', 'priority'],
              },
            },
            cashflowForecast: { type: Type.STRING, description: '2-3 sentence projection for end-of-month cash position' },
          },
          required: [
            'overallHealthScore',
            'healthRating',
            'summaryHeadline',
            'keyInsights',
            'monthlySavingsProjected',
            'savingsRatePercent',
            'leakAlerts',
            'recommendations',
            'cashflowForecast',
          ],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error conducting AI audit:', error);
    return res.status(500).json({ error: error.message || 'Audit generation failed' });
  }
});

/**
 * Endpoint: Interactive Financial Assistant Chat
 */
app.post('/api/ai/chat', async (req, res) => {
  try {
    const { message, history = [], budgetContext } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    if (!ai) {
      return res.json({
        reply: `I see your question regarding "${message}". Based on your budget summary, you have ${budgetContext?.currency || '$'}${budgetContext?.totalRemaining || 0} remaining in your active envelopes this month. For best peace of mind, prioritize your essential envelopes before making large discretionary purchases!`,
      });
    }

    const systemInstruction = `You are PacketSmart AI, the user's smart budget assistant and financial co-pilot.
You follow envelope/packet budgeting principles:
1. Every dollar has a job (assigned to a packet).
2. If an envelope runs low, you must pull from another envelope rather than going into unplanned debt.
3. Be encouraging, concise, highly analytical, and direct. Use specific numbers from their current budget context.
4. Format replies with clean typography, bullet points where suitable, and avoid generic filler.

User Budget Context:
- Monthly Income: ${budgetContext?.currency || '$'}${budgetContext?.monthlyIncome || 0}
- Total Spent: ${budgetContext?.currency || '$'}${budgetContext?.currentSpend || 0}
- Total Budgeted: ${budgetContext?.currency || '$'}${budgetContext?.totalBudgeted || 0}
- Packets Overview:
${JSON.stringify(budgetContext?.packets || [], null, 2)}`;

    // Prepare contents
    const contents: any[] = [];
    for (const h of history.slice(-6)) {
      contents.push({
        role: h.role === 'user' ? 'user' : 'model',
        parts: [{ text: h.text }],
      });
    }
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const reply = response.text || 'I analyzed your budget. Let me know if you would like me to adjust any packet allocations.';
    return res.json({ reply });
  } catch (error: any) {
    console.error('Error in AI chat:', error);
    return res.status(500).json({ error: error.message || 'Chat generation failed' });
  }
});

/**
 * Endpoint: Smart 50/30/20 & Goal-based Packet Allocator
 */
app.post('/api/ai/optimize-plan', async (req, res) => {
  try {
    const { monthlyIncome, goal, existingPackets, currency = '$' } = req.body;

    if (!ai) {
      // Heuristic 50/30/20 allocation
      const needs = monthlyIncome * 0.50;
      const wants = monthlyIncome * 0.30;
      const savings = monthlyIncome * 0.20;
      return res.json({
        strategyName: 'Classic 50/30/20 Smart Allocation',
        rationale: `Balanced foundation allocating 50% (${currency}${needs.toFixed(0)}) to Essentials, 30% (${currency}${wants.toFixed(0)}) to Discretionary, and 20% (${currency}${savings.toFixed(0)}) to Wealth & Emergency fund.`,
        suggestedAllocations: (existingPackets || []).map((p: any) => {
          let factor = 0.10;
          if (p.id === 'housing') factor = 0.32;
          else if (p.id === 'groceries') factor = 0.12;
          else if (p.id === 'savings') factor = 0.20;
          else if (p.id === 'dining') factor = 0.08;
          else if (p.id === 'transit') factor = 0.06;
          else factor = 0.04;
          return {
            packetId: p.id,
            packetName: p.name,
            recommendedAmount: Math.round(monthlyIncome * factor),
            difference: Math.round(monthlyIncome * factor) - (p.allocated || 0),
          };
        }),
      });
    }

    const prompt = `You are a financial planning engine.
The user has a monthly net income of ${currency}${monthlyIncome}.
Their goal or preference is: "${goal || 'Balanced wealth accumulation & healthy lifestyle'}".
Current packet configuration:
${JSON.stringify(existingPackets, null, 2)}

Provide a smart rebalanced allocation across each packet that sums exactly to ${monthlyIncome} (or within $5).
Provide a clear strategy name and analytical rationale for the changes.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            strategyName: { type: Type.STRING },
            rationale: { type: Type.STRING },
            suggestedAllocations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  packetId: { type: Type.STRING },
                  packetName: { type: Type.STRING },
                  recommendedAmount: { type: Type.NUMBER },
                  difference: { type: Type.NUMBER },
                },
                required: ['packetId', 'packetName', 'recommendedAmount', 'difference'],
              },
            },
          },
          required: ['strategyName', 'rationale', 'suggestedAllocations'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error optimizing plan:', error);
    return res.status(500).json({ error: error.message || 'Plan optimization failed' });
  }
});

// Setup Vite in Dev or serve static in Prod
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PacketSmart AI server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
