import React, { useState, useEffect } from 'react';
import {
  INITIAL_PROFILE,
  INITIAL_PACKETS,
  INITIAL_TRANSACTIONS,
  INITIAL_AUDIT,
} from './data/initialData';
import {
  Packet,
  Transaction,
  BudgetProfile,
  AIAuditResult,
  TransferRequest,
  AppSettings,
} from './types';
import { Header } from './components/Header';
import { QuickStats } from './components/QuickStats';
import { PacketsGrid } from './components/PacketsGrid';
import { TransactionModal } from './components/TransactionModal';
import { TransferModal } from './components/TransferModal';
import { AIAuditPanel } from './components/AIAuditPanel';
import { AIChatDrawer } from './components/AIChatDrawer';
import { TransactionLedger } from './components/TransactionLedger';
import { PacketOptimizerModal } from './components/PacketOptimizerModal';
import { EditPacketModal } from './components/EditPacketModal';
import { SettingsModal } from './components/SettingsModal';
import { ChartsSection } from './components/ChartsSection';
import { AlertsBanner } from './components/AlertsBanner';
import {
  Sparkles,
  PieChart,
  ArrowRight,
  ShieldAlert,
  RotateCcw,
  CheckCircle2,
  Wallet,
  Shield,
  BarChart3,
} from 'lucide-react';

const DEFAULT_SETTINGS: AppSettings = {
  currency: 'USD',
  currencySymbol: '$',
  language: 'en',
  budgetPeriodStartDay: 1,
  budgetPeriodType: 'calendar',
  monthlyIncome: 4850,
  userGoal: 'Grow emergency fund and maintain 20%+ savings rate',
  privacyMode: false,
};

export default function App() {
  // Navigation active tab
  const [activeTab, setActiveTab] = useState<'overview' | 'ledger' | 'charts' | 'audit' | 'chat'>('overview');

  // Application Settings
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('packetsmart_settings');
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });

  // Core financial state with localStorage persistence
  const [profile, setProfile] = useState<BudgetProfile>(() => {
    const saved = localStorage.getItem('packetsmart_profile');
    return saved
      ? JSON.parse(saved)
      : {
          ...INITIAL_PROFILE,
          currency: DEFAULT_SETTINGS.currencySymbol,
          monthlyIncome: DEFAULT_SETTINGS.monthlyIncome,
        };
  });

  const [packets, setPackets] = useState<Packet[]>(() => {
    const saved = localStorage.getItem('packetsmart_packets');
    return saved ? JSON.parse(saved) : INITIAL_PACKETS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('packetsmart_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [audit, setAudit] = useState<AIAuditResult>(() => {
    const saved = localStorage.getItem('packetsmart_audit');
    return saved ? JSON.parse(saved) : INITIAL_AUDIT;
  });

  // Modal states
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [logModalDefaultPacket, setLogModalDefaultPacket] = useState<string | undefined>(undefined);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferDefaultFrom, setTransferDefaultFrom] = useState<string | undefined>(undefined);
  const [transferDefaultTo, setTransferDefaultTo] = useState<string | undefined>(undefined);

  const [isOptimizerOpen, setIsOptimizerOpen] = useState(false);

  const [isEditPacketOpen, setIsEditPacketOpen] = useState(false);
  const [editingPacket, setEditingPacket] = useState<Packet | null>(null);

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Transient toast message
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Save states to localStorage
  useEffect(() => {
    localStorage.setItem('packetsmart_settings', JSON.stringify(settings));
    // Keep profile aligned with settings
    setProfile((prev) => ({
      ...prev,
      currency: settings.currencySymbol,
      monthlyIncome: settings.monthlyIncome,
      userGoal: settings.userGoal,
    }));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('packetsmart_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('packetsmart_packets', JSON.stringify(packets));
  }, [packets]);

  useEffect(() => {
    localStorage.setItem('packetsmart_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('packetsmart_audit', JSON.stringify(audit));
  }, [audit]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Recalculate packet spending based on transactions
  const recalculatePackets = (txList: Transaction[], currentPackets: Packet[]): Packet[] => {
    const spendMap: Record<string, number> = {};
    for (const tx of txList) {
      if (tx.type === 'expense') {
        spendMap[tx.packetId] = (spendMap[tx.packetId] || 0) + tx.amount;
      }
    }
    return currentPackets.map((p) => ({
      ...p,
      spent: spendMap[p.id] || 0,
    }));
  };

  // Handlers for Add and Edit transactions
  const handleSaveTransaction = (txData: Omit<Transaction, 'id'>, editId?: string) => {
    let updatedTxList: Transaction[];

    if (editId) {
      // Editing existing transaction
      updatedTxList = transactions.map((t) =>
        t.id === editId ? { ...txData, id: editId } : t
      );
      showToast(`Updated transaction "${txData.title}"`);
    } else {
      // Adding new transaction
      const newTx: Transaction = {
        ...txData,
        id: `tx-${Date.now()}`,
      };
      updatedTxList = [newTx, ...transactions];
      showToast(`Logged "${newTx.title}" to ${newTx.packetName}`);
    }

    setTransactions(updatedTxList);
    const updatedPackets = recalculatePackets(updatedTxList, packets);
    setPackets(updatedPackets);
    setEditingTransaction(null);
  };

  const handleEditTransaction = (tx: Transaction) => {
    setEditingTransaction(tx);
    setIsLogModalOpen(true);
  };

  const handleDeleteTransaction = (id: string) => {
    const updatedTxList = transactions.filter((t) => t.id !== id);
    setTransactions(updatedTxList);
    const updatedPackets = recalculatePackets(updatedTxList, packets);
    setPackets(updatedPackets);
    showToast('Transaction removed');
  };

  const handleExecuteTransfer = ({ fromPacketId, toPacketId, amount, note }: TransferRequest) => {
    const fromPacket = packets.find((p) => p.id === fromPacketId);
    const toPacket = packets.find((p) => p.id === toPacketId);
    if (!fromPacket || !toPacket) return;

    // Shift allocated amount
    const updatedPackets = packets.map((p) => {
      if (p.id === fromPacketId) {
        return { ...p, allocated: Math.max(0, p.allocated - amount) };
      }
      if (p.id === toPacketId) {
        return { ...p, allocated: p.allocated + amount };
      }
      return p;
    });

    setPackets(updatedPackets);

    // Add note transaction for audit trail
    const transferTx: Transaction = {
      id: `transfer-${Date.now()}`,
      title: `Envelope Transfer: ${fromPacket.name} → ${toPacket.name}`,
      amount,
      type: 'expense',
      packetId: fromPacketId,
      packetName: fromPacket.name,
      category: 'Transfer',
      merchant: 'Internal Allocation',
      date: new Date().toISOString().split('T')[0],
      notes: note || 'Rebalanced envelope funds',
    };

    setTransactions([transferTx, ...transactions]);
    showToast(
      `Shifted ${settings.currencySymbol}${amount.toFixed(2)} from ${fromPacket.name} to ${toPacket.name}`
    );
  };

  const handleApplyRecommendation = (rec: any) => {
    // If recommendation is to shift funds (e.g. Travel to Dining)
    if (rec.category === 'Packet Rebalance') {
      const travelPacket = packets.find((p) => p.id === 'fun-travel');
      const diningPacket = packets.find((p) => p.id === 'dining');
      if (travelPacket && diningPacket) {
        handleExecuteTransfer({
          fromPacketId: 'fun-travel',
          toPacketId: 'dining',
          amount: 25,
          note: 'AI Audit recommended cushion shift',
        });
        return;
      }
    }

    showToast(`Applied AI recommendation: "${rec.title}"`);
  };

  const handleApplyAllocations = (updatedPackets: Packet[]) => {
    setPackets(updatedPackets);
    showToast('Applied new envelope allocations successfully!');
  };

  const handleSavePacket = (packet: Packet) => {
    const existingIndex = packets.findIndex((p) => p.id === packet.id);
    if (existingIndex >= 0) {
      const updated = [...packets];
      updated[existingIndex] = packet;
      setPackets(updated);
      showToast(`Updated "${packet.name}"`);
    } else {
      setPackets([...packets, packet]);
      showToast(`Created envelope "${packet.name}"`);
    }
  };

  const handleDeletePacket = (packetId: string) => {
    const updated = packets.filter((p) => p.id !== packetId);
    setPackets(updated);
    showToast('Envelope deleted');
  };

  const handleResetData = () => {
    setProfile(INITIAL_PROFILE);
    setPackets(INITIAL_PACKETS);
    setTransactions(INITIAL_TRANSACTIONS);
    setAudit(INITIAL_AUDIT);
    setSettings(DEFAULT_SETTINGS);
    localStorage.clear();
    showToast('Reset all data to initial demonstration state');
  };

  // 50/30/20 Breakdown metrics
  const needsSpend = packets
    .filter((p) => p.isEssential)
    .reduce((acc, p) => acc + p.spent, 0);
  const wantsSpend = packets
    .filter((p) => !p.isEssential && p.id !== 'savings')
    .reduce((acc, p) => acc + p.spent, 0);
  const wealthSpend = packets
    .filter((p) => p.id === 'savings')
    .reduce((acc, p) => acc + p.spent, 0);

  const totalSpent = packets.reduce((acc, p) => acc + p.spent, 0);
  const needsPct = totalSpent > 0 ? Math.round((needsSpend / totalSpent) * 100) : 50;
  const wantsPct = totalSpent > 0 ? Math.round((wantsSpend / totalSpent) * 100) : 30;
  const wealthPct = totalSpent > 0 ? Math.round((wealthSpend / totalSpent) * 100) : 20;

  // Caution or Overspent alerts count
  const alertCount = packets.filter(
    (p) => p.allocated > 0 && p.spent / p.allocated >= 0.8
  ).length;

  return (
    <div className="min-h-screen bg-[#0b1120] text-slate-100 flex flex-col font-sans">
      {/* Top Header Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenLogModal={() => {
          setEditingTransaction(null);
          setLogModalDefaultPacket(undefined);
          setIsLogModalOpen(true);
        }}
        onOpenTransferModal={() => {
          setTransferDefaultFrom(undefined);
          setTransferDefaultTo(undefined);
          setIsTransferModalOpen(true);
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        privacyMode={settings.privacyMode}
        onTogglePrivacy={() =>
          setSettings((prev) => ({ ...prev, privacyMode: !prev.privacyMode }))
        }
        alertCount={alertCount}
        userAvatarUrl="/src/assets/images/user_avatar_finance_1790574577720.jpg"
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Toast notification */}
        {toastMessage && (
          <div className="fixed bottom-5 right-5 z-50 bg-slate-900 border border-emerald-500/30 text-white text-xs px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* TAB 1: Dashboard / Overview */}
        {activeTab === 'overview' && (
          <div className="space-y-6 sm:space-y-8">
            {/* Active Budget Alerts Banner */}
            <AlertsBanner
              packets={packets}
              currencySymbol={settings.currencySymbol}
              onOpenTransfer={(fromId, toId) => {
                setTransferDefaultFrom(fromId || 'fun-travel');
                setTransferDefaultTo(toId);
                setIsTransferModalOpen(true);
              }}
              onEditLimit={(packet) => {
                setEditingPacket(packet);
                setIsEditPacketOpen(true);
              }}
            />

            {/* Core Metrics: Current Balance, Income, Expenses, Budget Progress */}
            <QuickStats
              profile={profile}
              packets={packets}
              privacyMode={settings.privacyMode}
              budgetPeriodStartDay={settings.budgetPeriodStartDay}
              onOpenOptimizer={() => setIsOptimizerOpen(true)}
            />

            {/* Smart Envelope Insights Bento Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* 50/30/20 Ratio Visualizer */}
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span className="font-semibold text-slate-200">50/30/20 Envelope Ratio</span>
                    <PieChart className="w-4 h-4 text-emerald-400" />
                  </div>
                  <p className="text-xs text-slate-400 mb-4">
                    Current expenditure division against classic balanced benchmarks.
                  </p>

                  {/* Multi-segment progress bar */}
                  <div className="w-full bg-slate-800 rounded-full h-3 flex overflow-hidden mb-3">
                    <div
                      style={{ width: `${needsPct}%` }}
                      className="bg-blue-500 transition-all duration-300"
                      title={`Needs: ${needsPct}%`}
                    />
                    <div
                      style={{ width: `${wantsPct}%` }}
                      className="bg-amber-500 transition-all duration-300"
                      title={`Wants: ${wantsPct}%`}
                    />
                    <div
                      style={{ width: `${wealthPct}%` }}
                      className="bg-emerald-500 transition-all duration-300"
                      title={`Wealth: ${wealthPct}%`}
                    />
                  </div>

                  <div className="grid grid-cols-3 text-center text-xs font-mono tabular-nums">
                    <div className="text-left">
                      <div className="text-blue-400 font-bold">{needsPct}%</div>
                      <div className="text-[11px] text-slate-400 font-sans">Needs (50%)</div>
                    </div>
                    <div>
                      <div className="text-amber-400 font-bold">{wantsPct}%</div>
                      <div className="text-[11px] text-slate-400 font-sans">Wants (30%)</div>
                    </div>
                    <div className="text-right">
                      <div className="text-emerald-400 font-bold">{wealthPct}%</div>
                      <div className="text-[11px] text-slate-400 font-sans">Wealth (20%)</div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Balanced Distribution</span>
                  <button
                    onClick={() => setIsOptimizerOpen(true)}
                    className="text-emerald-400 hover:text-emerald-300 font-medium"
                  >
                    Adjust Targets →
                  </button>
                </div>
              </div>

              {/* Dynamic Spending Trends Snapshot */}
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span className="font-semibold text-slate-200">Spending Trends & Analytics</span>
                    <BarChart3 className="w-4 h-4 text-emerald-400" />
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed mb-3">
                    Analyze daily burn velocity, envelope caps, and category percentages in high-resolution interactive charts.
                  </p>

                  <div className="p-3 bg-slate-800/50 border border-slate-800 rounded-lg flex items-center justify-between text-xs">
                    <span className="text-slate-400">Total Envelopes:</span>
                    <span className="font-mono font-semibold text-white">{packets.length}</span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <button
                    onClick={() => setActiveTab('charts')}
                    className="text-emerald-400 hover:text-emerald-300 font-medium inline-flex items-center gap-1"
                  >
                    <span>Open Interactive Charts</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setActiveTab('audit')}
                    className="text-slate-400 hover:text-slate-200"
                  >
                    AI Audit
                  </button>
                </div>
              </div>

              {/* Smart Card Visual Asset Card */}
              <div className="relative bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-xl p-5 overflow-hidden flex flex-col justify-between group">
                <div className="relative z-10">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span className="font-semibold text-slate-200">Envelope Spending Rules</span>
                    <Wallet className="w-4 h-4 text-emerald-400" />
                  </div>
                  <p className="text-xs text-slate-400">
                    Never spend money you don’t have. If one envelope runs dry, transfer cushion before swiping.
                  </p>
                </div>

                <div className="relative z-10 mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-lg overflow-hidden border border-slate-700 bg-slate-800 shrink-0">
                      <img
                        src="/src/assets/images/smart_budget_card_1790574596024.jpg"
                        alt="Smart Card"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white">Packet Smart Debit</div>
                      <div className="text-[11px] text-slate-500 font-mono">•••• 8421</div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setEditingTransaction(null);
                      setLogModalDefaultPacket(undefined);
                      setIsLogModalOpen(true);
                    }}
                    className="px-2.5 py-1 text-xs font-semibold bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg transition-colors"
                  >
                    + Log Spend
                  </button>
                </div>
              </div>
            </div>

            {/* Envelope Grid Section */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-base font-bold text-white tracking-tight">Active Envelopes & Limits</h3>
                <span className="text-xs text-slate-400 font-mono tabular-nums">
                  {packets.length} Envelopes
                </span>
              </div>
              <PacketsGrid
                packets={packets}
                currency={settings.currencySymbol}
                privacyMode={settings.privacyMode}
                onLogToPacket={(packetId) => {
                  setEditingTransaction(null);
                  setLogModalDefaultPacket(packetId);
                  setIsLogModalOpen(true);
                }}
                onTransferFromPacket={(packetId) => {
                  setTransferDefaultFrom(packetId);
                  setTransferDefaultTo(undefined);
                  setIsTransferModalOpen(true);
                }}
                onEditPacket={(packet) => {
                  setEditingPacket(packet);
                  setIsEditPacketOpen(true);
                }}
                onAddNewPacket={() => {
                  setEditingPacket(null);
                  setIsEditPacketOpen(true);
                }}
              />
            </div>

            {/* Recent Transactions Mini-Ledger Preview */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="text-sm font-semibold text-white">Recent Transactions</h4>
                  <div className="text-xs text-slate-400">Latest debits & inflows logged</div>
                </div>
                <button
                  onClick={() => setActiveTab('ledger')}
                  className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 inline-flex items-center gap-1"
                >
                  <span>Full Ledger ({transactions.length})</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="divide-y divide-slate-800/80">
                {transactions.slice(0, 5).map((tx) => (
                  <div key={tx.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div className="text-slate-400 font-mono tabular-nums w-20">{tx.date}</div>
                      <div>
                        <div className="font-medium text-white">{tx.title}</div>
                        <div className="text-[11px] text-slate-400">{tx.packetName}</div>
                      </div>
                    </div>
                    <div
                      className={`font-mono tabular-nums font-semibold ${
                        tx.type === 'expense' ? 'text-slate-200' : 'text-emerald-400'
                      }`}
                    >
                      {settings.privacyMode ? (
                        '••••'
                      ) : (
                        <>
                          {tx.type === 'expense' ? '-' : '+'}
                          {settings.currencySymbol}
                          {tx.amount.toFixed(2)}
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: Full Transaction Ledger with Search, Filters, and Editing */}
        {activeTab === 'ledger' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-white tracking-tight">Transaction Ledger</h2>
                <p className="text-xs text-slate-400">
                  Search and filter by date, category, envelope, and amount. Add or edit entries anytime.
                </p>
              </div>
              <button
                onClick={() => {
                  setEditingTransaction(null);
                  setLogModalDefaultPacket(undefined);
                  setIsLogModalOpen(true);
                }}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm transition-all"
              >
                + Log Entry
              </button>
            </div>

            <TransactionLedger
              transactions={transactions}
              packets={packets}
              currency={settings.currencySymbol}
              privacyMode={settings.privacyMode}
              onEditTransaction={handleEditTransaction}
              onDeleteTransaction={handleDeleteTransaction}
              onOpenLogModal={() => {
                setEditingTransaction(null);
                setLogModalDefaultPacket(undefined);
                setIsLogModalOpen(true);
              }}
            />
          </div>
        )}

        {/* TAB 3: Visual Charts & Comparisons */}
        {activeTab === 'charts' && (
          <ChartsSection
            packets={packets}
            transactions={transactions}
            currencySymbol={settings.currencySymbol}
            monthlyIncome={settings.monthlyIncome}
            privacyMode={settings.privacyMode}
          />
        )}

        {/* TAB 4: Smart AI Budget Audit */}
        {activeTab === 'audit' && (
          <AIAuditPanel
            audit={audit}
            profile={profile}
            packets={packets}
            transactions={transactions}
            onApplyRecommendation={handleApplyRecommendation}
            onUpdateAudit={(newAudit) => {
              setAudit(newAudit);
              showToast('AI Budget Audit updated!');
            }}
          />
        )}

        {/* TAB 5: Ask Packet Smart AI Advisor */}
        {activeTab === 'chat' && (
          <AIChatDrawer
            profile={profile}
            packets={packets}
            transactions={transactions}
            privacyMode={settings.privacyMode}
          />
        )}
      </main>

      {/* Footer with Legal & Privacy Disclaimers */}
      <footer className="border-t border-slate-800/80 bg-slate-900/60 py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">Packet Smart AI</span>
            <span>·</span>
            <span>Intelligent Personal Budgeting & Expense Assistant</span>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-[11px] text-slate-400">
            <span className="flex items-center gap-1 text-slate-400">
              <Shield className="w-3 h-3 text-emerald-400" />
              <span>Private & Local Data</span>
            </span>
            <span>·</span>
            <span>Educational guidance only · Not certified financial advice</span>
            <span>·</span>
            <button
              onClick={handleResetData}
              className="text-slate-400 hover:text-slate-200 flex items-center gap-1 transition-colors"
              title="Reset sample data"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Data</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Transaction Add / Edit Modal */}
      <TransactionModal
        isOpen={isLogModalOpen}
        onClose={() => {
          setIsLogModalOpen(false);
          setEditingTransaction(null);
        }}
        packets={packets}
        currency={settings.currencySymbol}
        defaultPacketId={logModalDefaultPacket}
        editingTransaction={editingTransaction}
        onSaveTransaction={handleSaveTransaction}
      />

      {/* Envelope Transfer Modal */}
      <TransferModal
        isOpen={isTransferModalOpen}
        onClose={() => setIsTransferModalOpen(false)}
        packets={packets}
        currency={settings.currencySymbol}
        defaultFromPacketId={transferDefaultFrom}
        onExecuteTransfer={handleExecuteTransfer}
      />

      {/* Packet Optimizer Modal */}
      <PacketOptimizerModal
        isOpen={isOptimizerOpen}
        onClose={() => setIsOptimizerOpen(false)}
        packets={packets}
        profile={profile}
        onApplyAllocations={handleApplyAllocations}
      />

      {/* Envelope Edit Modal */}
      <EditPacketModal
        isOpen={isEditPacketOpen}
        onClose={() => setIsEditPacketOpen(false)}
        packet={editingPacket}
        currency={settings.currencySymbol}
        onSavePacket={handleSavePacket}
        onDeletePacket={editingPacket ? handleDeletePacket : undefined}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={(newSettings) => {
          setSettings(newSettings);
          showToast('Settings saved successfully!');
        }}
        onResetData={handleResetData}
      />
    </div>
  );
}
