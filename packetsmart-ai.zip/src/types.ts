export type TransactionType = 'expense' | 'income';

export interface Packet {
  id: string;
  name: string;
  category: string;
  allocated: number;
  spent: number;
  icon: string;
  color: string;
  description: string;
  isEssential?: boolean;
}

export interface Transaction {
  id: string;
  title: string;
  amount: number;
  type: TransactionType;
  packetId: string;
  packetName: string;
  category: string;
  merchant: string;
  date: string;
  notes?: string;
  isRecurring?: boolean;
}

export interface AppSettings {
  currency: string;
  currencySymbol: string;
  language: string;
  budgetPeriodStartDay: number; // e.g. 1 for 1st of month, 15 for 15th
  budgetPeriodType: 'calendar' | 'payday' | 'custom';
  monthlyIncome: number;
  userGoal: string;
  privacyMode: boolean; // hide balances when active
}

export interface BudgetAlert {
  id: string;
  type: 'danger' | 'warning' | 'info';
  packetId: string;
  packetName: string;
  title: string;
  message: string;
  percentUsed: number;
  amountOver?: number;
  amountRemaining?: number;
}

export interface BudgetProfile {
  currency: string;
  monthlyIncome: number;
  payCycle: 'monthly' | 'biweekly' | 'weekly';
  userGoal: string;
}

export interface LeakAlert {
  packetName: string;
  title: string;
  description: string;
  estimatedMonthlyLeak: number;
}

export interface Recommendation {
  title: string;
  category: string;
  impact: string;
  actionPlan: string;
  priority: 'high' | 'medium' | 'low';
}

export interface AIAuditResult {
  overallHealthScore: number;
  healthRating: 'Excellent' | 'Good' | 'Caution' | 'Action Needed';
  summaryHeadline: string;
  keyInsights: string[];
  monthlySavingsProjected: number;
  savingsRatePercent: number;
  leakAlerts: LeakAlert[];
  recommendations: Recommendation[];
  cashflowForecast: string;
}

export interface TransferRequest {
  fromPacketId: string;
  toPacketId: string;
  amount: number;
  note?: string;
}

