import React, { useState } from 'react';
import { X, Sparkles, Check, ArrowRight, Loader2 } from 'lucide-react';
import { Packet, BudgetProfile } from '../types';

interface PacketOptimizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  packets: Packet[];
  profile: BudgetProfile;
  onApplyAllocations: (updatedPackets: Packet[]) => void;
}

interface AllocationDiff {
  packetId: string;
  packetName: string;
  current: number;
  recommended: number;
  diff: number;
}

export const PacketOptimizerModal: React.FC<PacketOptimizerModalProps> = ({
  isOpen,
  onClose,
  packets,
  profile,
  onApplyAllocations,
}) => {
  const [selectedStrategy, setSelectedStrategy] = useState<'50-30-20' | 'aggressive' | 'lifestyle' | 'custom'>('50-30-20');
  const [customGoal, setCustomGoal] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [strategyRationale, setStrategyRationale] = useState(
    'Allocates 50% ($' +
      (profile.monthlyIncome * 0.5).toFixed(0) +
      ') to Essential Needs, 30% ($' +
      (profile.monthlyIncome * 0.3).toFixed(0) +
      ') to Lifestyle, and 20% ($' +
      (profile.monthlyIncome * 0.2).toFixed(0) +
      ') to Wealth and Emergency Reserves.'
  );

  const calculateProposed = (strategy: string): AllocationDiff[] => {
    const income = profile.monthlyIncome;
    let factorMap: Record<string, number> = {};

    if (strategy === '50-30-20') {
      factorMap = {
        housing: 0.32,
        groceries: 0.11,
        transit: 0.05,
        health: 0.02,
        dining: 0.08,
        entertainment: 0.04,
        'fun-travel': 0.08,
        savings: 0.30,
      };
    } else if (strategy === 'aggressive') {
      // 40% savings
      factorMap = {
        housing: 0.30,
        groceries: 0.09,
        transit: 0.04,
        health: 0.02,
        dining: 0.05,
        entertainment: 0.02,
        'fun-travel': 0.04,
        savings: 0.44,
      };
    } else {
      // lifestyle balance
      factorMap = {
        housing: 0.32,
        groceries: 0.12,
        transit: 0.05,
        health: 0.03,
        dining: 0.10,
        entertainment: 0.05,
        'fun-travel': 0.11,
        savings: 0.22,
      };
    }

    return packets.map((p) => {
      const factor = factorMap[p.id] || 0.05;
      const rec = Math.round(income * factor);
      return {
        packetId: p.id,
        packetName: p.name,
        current: p.allocated,
        recommended: rec,
        diff: rec - p.allocated,
      };
    });
  };

  const [proposedList, setProposedList] = useState<AllocationDiff[]>(() => calculateProposed('50-30-20'));

  if (!isOpen) return null;

  const handleStrategyChange = (st: '50-30-20' | 'aggressive' | 'lifestyle' | 'custom') => {
    setSelectedStrategy(st);
    if (st !== 'custom') {
      const list = calculateProposed(st);
      setProposedList(list);
      if (st === '50-30-20') {
        setStrategyRationale(
          'Classic 50/30/20 division establishing solid baseline resilience and 20%+ savings.'
        );
      } else if (st === 'aggressive') {
        setStrategyRationale(
          'High-acceleration FIRE model compressing lifestyle envelopes to route maximum surplus into Wealth.'
        );
      } else {
        setStrategyRationale(
          'Comfortable living with expanded leisure envelopes while maintaining a 20%+ wealth contribution.'
        );
      }
    }
  };

  const handleCustomAISubmit = async () => {
    if (!customGoal.trim()) return;
    setIsLoading(true);

    try {
      const res = await fetch('/api/ai/optimize-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          monthlyIncome: profile.monthlyIncome,
          goal: customGoal,
          existingPackets: packets,
          currency: profile.currency,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setStrategyRationale(data.rationale || 'Custom AI-generated envelope redistribution.');
        if (Array.isArray(data.suggestedAllocations)) {
          const updated = packets.map((p) => {
            const found = data.suggestedAllocations.find((s: any) => s.packetId === p.id);
            const rec = found ? found.recommendedAmount : p.allocated;
            return {
              packetId: p.id,
              packetName: p.name,
              current: p.allocated,
              recommended: rec,
              diff: rec - p.allocated,
            };
          });
          setProposedList(updated);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = () => {
    const updated = packets.map((p) => {
      const match = proposedList.find((item) => item.packetId === p.id);
      return match ? { ...p, allocated: match.recommended } : p;
    });

    onApplyAllocations(updated);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">Smart Envelope Rebalance</h3>
              <p className="text-xs text-slate-400">
                Optimize monthly allocations across all envelopes based on your net income
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto space-y-4">
          {/* Strategy buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { id: '50-30-20', label: '50/30/20 Rule' },
              { id: 'aggressive', label: 'Aggressive FIRE' },
              { id: 'lifestyle', label: 'Balanced Leisure' },
              { id: 'custom', label: 'AI Custom Goal' },
            ].map((st) => (
              <button
                key={st.id}
                onClick={() => handleStrategyChange(st.id as any)}
                className={`px-3 py-2 text-xs font-semibold rounded-xl border text-center transition-colors ${
                  selectedStrategy === st.id
                    ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-300'
                    : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>

          {selectedStrategy === 'custom' && (
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={customGoal}
                onChange={(e) => setCustomGoal(e.target.value)}
                placeholder="e.g. Save $1,200 for a Europe trip while keeping rent fixed"
                className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-emerald-500"
              />
              <button
                onClick={handleCustomAISubmit}
                disabled={isLoading || !customGoal.trim()}
                className="px-3 py-2 bg-emerald-400 text-slate-950 font-semibold rounded-lg text-xs flex items-center gap-1 shrink-0 disabled:bg-slate-800 disabled:text-slate-500"
              >
                {isLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                Generate
              </button>
            </div>
          )}

          {/* Rationale explanation */}
          <div className="bg-slate-800/50 border border-slate-800 p-3 rounded-xl text-xs text-slate-300 leading-relaxed">
            <span className="font-semibold text-emerald-400">Strategy Rationale: </span>
            {strategyRationale}
          </div>

          {/* Table of before / proposed */}
          <div className="border border-slate-800 rounded-xl overflow-hidden text-xs">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-800/80 text-[11px] font-semibold text-slate-400 border-b border-slate-800">
                  <th className="py-2 px-3">Envelope</th>
                  <th className="py-2 px-3 text-right">Current</th>
                  <th className="py-2 px-3 text-right">Proposed</th>
                  <th className="py-2 px-3 text-right">Change</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono tabular-nums">
                {proposedList.map((item) => (
                  <tr key={item.packetId} className="hover:bg-slate-800/30">
                    <td className="py-2 px-3 text-slate-200 font-sans font-medium">
                      {item.packetName}
                    </td>
                    <td className="py-2 px-3 text-right text-slate-400">
                      {profile.currency}{item.current.toLocaleString()}
                    </td>
                    <td className="py-2 px-3 text-right font-semibold text-white">
                      {profile.currency}{item.recommended.toLocaleString()}
                    </td>
                    <td className="py-2 px-3 text-right">
                      {item.diff === 0 ? (
                        <span className="text-slate-500">—</span>
                      ) : item.diff > 0 ? (
                        <span className="text-emerald-400">+{profile.currency}{item.diff}</span>
                      ) : (
                        <span className="text-amber-400">-{profile.currency}{Math.abs(item.diff)}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-between px-6 py-3.5 border-t border-slate-800 bg-slate-900/90">
          <div className="text-xs text-slate-400 font-mono tabular-nums">
            Total Allocated:{' '}
            <span className="text-white font-bold">
              {profile.currency}
              {proposedList.reduce((acc, p) => acc + p.recommended, 0).toLocaleString()}
            </span>{' '}
            / {profile.currency}{profile.monthlyIncome.toLocaleString()}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-400 hover:text-slate-200 bg-slate-800 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm transition-all flex items-center gap-1"
            >
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
              Apply New Allocations
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
