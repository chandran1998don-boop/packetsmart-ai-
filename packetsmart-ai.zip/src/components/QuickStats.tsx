import React from 'react';
import { TrendingUp, ArrowDownRight, Wallet, PiggyBank, Sparkles, DollarSign, PieChart } from 'lucide-react';
import { BudgetProfile, Packet } from '../types';

interface QuickStatsProps {
  profile: BudgetProfile;
  packets: Packet[];
  privacyMode?: boolean;
  budgetPeriodStartDay?: number;
  onOpenOptimizer: () => void;
}

export const QuickStats: React.FC<QuickStatsProps> = ({
  profile,
  packets,
  privacyMode = false,
  budgetPeriodStartDay = 1,
  onOpenOptimizer,
}) => {
  const { currency, monthlyIncome } = profile;

  // Calculate totals
  const totalAllocated = packets.reduce((acc, p) => acc + p.allocated, 0);
  const totalSpent = packets.reduce((acc, p) => acc + p.spent, 0);
  const currentBalance = Math.max(0, monthlyIncome - totalSpent);
  const totalRemaining = Math.max(0, totalAllocated - totalSpent);
  const budgetProgressPct = totalAllocated > 0 ? Math.min(100, Math.round((totalSpent / totalAllocated) * 100)) : 0;

  // Wealth/Savings dedicated packet
  const wealthPacket = packets.find((p) => p.id === 'savings');
  const dedicatedSavings = wealthPacket ? wealthPacket.allocated : 0;

  // Projected savings rate = (dedicated savings + unspent remaining) / income
  const totalProjectedSavings = dedicatedSavings + (monthlyIncome - totalAllocated);
  const savingsRate =
    monthlyIncome > 0
      ? Math.min(100, Math.max(0, Math.round((totalProjectedSavings / monthlyIncome) * 100)))
      : 0;

  // Days left in current cycle
  const now = new Date();
  const currentDay = now.getDate();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  let daysLeft = daysInMonth - currentDay;
  if (daysLeft <= 0) daysLeft = 1;

  const dailyAllowance = daysLeft > 0 ? (totalRemaining / daysLeft).toFixed(2) : '0.00';

  const formatAmount = (val: number, decimals = 0) => {
    if (privacyMode) return '••••';
    return `${currency}${val.toLocaleString(undefined, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    })}`;
  };

  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4 mb-6 sm:mb-8">
      {/* 1. Current Available Balance */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3.5 sm:p-4 transition-colors hover:border-slate-700">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
          <span className="font-medium">Current Balance</span>
          <Wallet className="w-3.5 h-3.5 text-emerald-400" />
        </div>
        <div className="text-xl sm:text-2xl font-bold tracking-tight text-white font-mono tabular-nums">
          {formatAmount(currentBalance, 2)}
        </div>
        <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
          <span>Available cash</span>
          <span aria-hidden="true">·</span>
          <span className="text-emerald-400 font-medium">Safe</span>
        </div>
      </div>

      {/* 2. Monthly Income */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3.5 sm:p-4 transition-colors hover:border-slate-700">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
          <span className="font-medium">Monthly Inflow</span>
          <DollarSign className="w-3.5 h-3.5 text-slate-500" />
        </div>
        <div className="text-xl sm:text-2xl font-bold tracking-tight text-slate-200 font-mono tabular-nums">
          {formatAmount(monthlyIncome, 0)}
        </div>
        <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
          <span>Net Take-home</span>
          <span aria-hidden="true">·</span>
          <span>{profile.payCycle}</span>
        </div>
      </div>

      {/* 3. Monthly Expenses (Spent to Date) */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3.5 sm:p-4 transition-colors hover:border-slate-700">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
          <span className="font-medium">Monthly Outflows</span>
          <ArrowDownRight className="w-3.5 h-3.5 text-amber-400/80" />
        </div>
        <div className="text-xl sm:text-2xl font-bold tracking-tight text-amber-300 font-mono tabular-nums">
          {formatAmount(totalSpent, 2)}
        </div>
        <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
          <span>{daysLeft} days remaining</span>
          <span aria-hidden="true">·</span>
          <span>{packets.length} envelopes</span>
        </div>
      </div>

      {/* 4. Budget Progress & Remaining Cushion */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3.5 sm:p-4 transition-colors hover:border-slate-700">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
          <span className="font-medium">Budget Progress</span>
          <PiggyBank className="w-3.5 h-3.5 text-emerald-400/80" />
        </div>
        <div className="text-xl sm:text-2xl font-bold tracking-tight text-emerald-400 font-mono tabular-nums">
          {budgetProgressPct}%
        </div>
        {/* Subtle mini progress bar */}
        <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden my-1">
          <div
            style={{ width: `${budgetProgressPct}%` }}
            className={`h-full transition-all duration-300 ${
              budgetProgressPct > 90 ? 'bg-amber-400' : 'bg-emerald-400'
            }`}
          />
        </div>
        <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
          <span className="font-mono tabular-nums">{formatAmount(totalRemaining, 0)} left</span>
          <span aria-hidden="true">·</span>
          <button
            onClick={onOpenOptimizer}
            className="text-emerald-400 hover:text-emerald-300 font-medium inline-flex items-center gap-0.5"
          >
            <Sparkles className="w-3 h-3" />
            Adjust
          </button>
        </div>
      </div>

      {/* 5. Net Projected Savings Rate */}
      <div className="col-span-2 lg:col-span-1 bg-gradient-to-br from-slate-900/80 to-emerald-950/20 border border-emerald-500/20 rounded-xl p-3.5 sm:p-4 transition-colors hover:border-emerald-500/30">
        <div className="flex items-center justify-between text-xs text-emerald-400/90 mb-1.5">
          <span className="font-semibold">Savings & Growth Rate</span>
          <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
        </div>
        <div className="text-xl sm:text-2xl font-bold tracking-tight text-emerald-300 font-mono tabular-nums">
          {savingsRate}%
        </div>
        <div className="mt-1 text-xs text-emerald-400/70 flex items-center gap-1.5">
          <span>Target: &gt;20%</span>
          <span aria-hidden="true">·</span>
          <span>Disciplined</span>
        </div>
      </div>
    </div>
  );
};
