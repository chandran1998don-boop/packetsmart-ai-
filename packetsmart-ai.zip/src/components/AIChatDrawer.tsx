import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, Loader2, Bot, User, HelpCircle, Shield, Info } from 'lucide-react';
import { BudgetProfile, Packet, Transaction } from '../types';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

interface AIChatDrawerProps {
  profile: BudgetProfile;
  packets: Packet[];
  transactions: Transaction[];
  privacyMode?: boolean;
}

const SUGGESTED_QUESTIONS = [
  "Give me 3 practical ways to save $150 this month",
  "Can I afford an unplanned $250 expense this weekend?",
  "Which envelope am I burning through fastest?",
  "How should I distribute a $500 bonus across envelopes?",
];

export const AIChatDrawer: React.FC<AIChatDrawerProps> = ({
  profile,
  packets,
  transactions,
  privacyMode = false,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      text: `Hello! I'm your Packet Smart AI assistant. I have full context of your ${profile.currency}${profile.monthlyIncome.toLocaleString()} monthly income, your ${packets.length} active envelopes, and your recent transactions. What financial question or saving goal can I help you crunch today?`,
      timestamp: 'Just now',
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || input;
    if (!text.trim() || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const currentSpend = packets.reduce((acc, p) => acc + p.spent, 0);
      const totalBudgeted = packets.reduce((acc, p) => acc + p.allocated, 0);

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: messages.slice(-6).map((m) => ({
            role: m.role,
            text: m.text,
          })),
          budgetContext: {
            currency: profile.currency,
            monthlyIncome: profile.monthlyIncome,
            currentSpend,
            totalBudgeted,
            totalRemaining: Math.max(0, totalBudgeted - currentSpend),
            packets: packets.map((p) => ({
              name: p.name,
              allocated: p.allocated,
              spent: p.spent,
              remaining: p.allocated - p.spent,
            })),
          },
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to reach AI assistant');
      }

      const data = await res.json();
      const modelMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: data.reply || 'Here is your budget assessment.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, modelMsg]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'model',
          text: 'I ran into a temporary hiccup crunching the numbers. Please try asking again!',
          timestamp: 'Just now',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const totalCushion = Math.max(
    0,
    packets.reduce((acc, p) => acc + p.allocated, 0) -
      packets.reduce((acc, p) => acc + p.spent, 0)
  );

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-2xl flex flex-col h-[650px] overflow-hidden">
      {/* Top Header */}
      <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Packet Smart AI Assistant</h3>
            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <span>Grounded in live envelope state</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-400">Ready to assist</span>
            </div>
          </div>
        </div>

        <div className="text-xs text-slate-400 font-mono tabular-nums hidden sm:block">
          Cushion:{' '}
          <strong className="text-emerald-400">
            {privacyMode ? '••••' : `${profile.currency}${totalCushion.toFixed(2)}`}
          </strong>
        </div>
      </div>

      {/* Persistent Privacy & Non-Advice Disclaimer */}
      <div className="px-4 py-2 bg-slate-950/60 border-b border-slate-800/80 flex items-center gap-2 text-[11px] text-slate-400">
        <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
        <span>
          Private & Secure · All suggestions are for educational budgeting purposes only, not professional financial advice.
        </span>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
                  <Bot className="w-3.5 h-3.5" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-emerald-500 text-slate-950 font-medium rounded-tr-sm'
                    : 'bg-slate-800/80 border border-slate-700/60 text-slate-200 rounded-tl-sm shadow-sm'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>
                <div
                  className={`text-[10px] mt-2 font-mono ${
                    isUser ? 'text-slate-900/70 text-right' : 'text-slate-400'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>

              {isUser && (
                <div className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0 mt-0.5">
                  <User className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-3 justify-start items-center">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
              <Bot className="w-3.5 h-3.5" />
            </div>
            <div className="bg-slate-800/80 border border-slate-700/60 text-slate-400 px-4 py-3 rounded-2xl rounded-tl-sm text-xs flex items-center gap-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />
              <span>Analyzing envelopes and crunching numbers...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Prompt Suggestions */}
      <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-900/50">
        <div className="text-[11px] text-slate-400 mb-1.5 flex items-center gap-1">
          <HelpCircle className="w-3 h-3 text-slate-400" />
          <span>Practical Questions & Suggestions:</span>
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {SUGGESTED_QUESTIONS.map((q) => (
            <button
              key={q}
              onClick={() => handleSendMessage(q)}
              disabled={isLoading}
              className="text-xs px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 whitespace-nowrap transition-colors"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Input Form */}
      <div className="p-4 border-t border-slate-800 bg-slate-900">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about spending cuts, envelope transfers, or saving decisions..."
            className="flex-1 bg-slate-800 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 outline-none transition-all"
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="p-2.5 bg-emerald-400 hover:bg-emerald-300 disabled:bg-slate-800 text-slate-950 disabled:text-slate-500 rounded-xl transition-colors shrink-0 shadow-sm"
          >
            <Send className="w-4 h-4 stroke-[2.5]" />
          </button>
        </form>
      </div>
    </div>
  );
};
