import React, { useState, useEffect } from 'react';
import { X, Sparkles, Loader2, Check, ArrowDownLeft, ArrowUpRight, Edit3 } from 'lucide-react';
import { Packet, Transaction, TransactionType } from '../types';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  packets: Packet[];
  currency: string;
  defaultPacketId?: string;
  editingTransaction?: Transaction | null;
  onSaveTransaction: (tx: Omit<Transaction, 'id'>, editId?: string) => void;
}

const QUICK_PROMPTS = [
  "☕ Blue Bottle coffee $6.75",
  "🛒 Trader Joe's groceries $74.20",
  "⚡ Pacific Gas & Electric $62.50",
  "🚗 Shell gas station $44.00",
  "💼 Freelance payout $450.00",
  "🍱 Team sushi dinner $52.00",
];

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  packets,
  currency,
  defaultPacketId,
  editingTransaction,
  onSaveTransaction,
}) => {
  const isEditing = Boolean(editingTransaction);

  const [mode, setMode] = useState<'ai' | 'manual'>(isEditing ? 'manual' : 'ai');
  const [nlInput, setNlInput] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);

  // Form fields
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState<string>('');
  const [type, setType] = useState<TransactionType>('expense');
  const [packetId, setPacketId] = useState(defaultPacketId || packets[0]?.id || 'groceries');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [merchant, setMerchant] = useState('');
  const [notes, setNotes] = useState('');
  const [hasParsedPreview, setHasParsedPreview] = useState(isEditing);

  useEffect(() => {
    if (editingTransaction) {
      setTitle(editingTransaction.title);
      setAmount(String(editingTransaction.amount));
      setType(editingTransaction.type);
      setPacketId(editingTransaction.packetId);
      setDate(editingTransaction.date);
      setMerchant(editingTransaction.merchant || '');
      setNotes(editingTransaction.notes || '');
      setMode('manual');
      setHasParsedPreview(true);
    } else {
      setTitle('');
      setAmount('');
      setType('expense');
      setPacketId(defaultPacketId || packets[0]?.id || 'groceries');
      setDate(new Date().toISOString().split('T')[0]);
      setMerchant('');
      setNotes('');
      setMode('ai');
      setHasParsedPreview(false);
    }
  }, [editingTransaction, defaultPacketId, isOpen, packets]);

  if (!isOpen) return null;

  const handleAIParse = async (customText?: string) => {
    const textToParse = customText || nlInput;
    if (!textToParse.trim()) return;

    setIsParsing(true);
    setParseError(null);

    try {
      const res = await fetch('/api/ai/parse-transaction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          input: textToParse,
          availablePackets: packets.map((p) => ({
            id: p.id,
            name: p.name,
            category: p.category,
          })),
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to parse text with AI');
      }

      const data = await res.json();
      setTitle(data.title || 'Transaction');
      setAmount(data.amount ? String(data.amount) : '');
      setType(data.type === 'income' ? 'income' : 'expense');

      // Match packet
      const matched = packets.find((p) => p.id === data.packetId);
      if (matched) {
        setPacketId(matched.id);
      } else if (packets.length > 0) {
        setPacketId(packets[0].id);
      }

      if (data.date) setDate(data.date);
      if (data.merchant) setMerchant(data.merchant);
      if (data.notes) setNotes(data.notes);

      setHasParsedPreview(true);
    } catch (err: any) {
      setParseError(err.message || 'Error parsing text. You can enter manually below.');
      setHasParsedPreview(true);
    } finally {
      setIsParsing(false);
    }
  };

  const handleQuickChipClick = (prompt: string) => {
    setNlInput(prompt);
    handleAIParse(prompt);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) return;

    const matchedPacket = packets.find((p) => p.id === packetId);

    onSaveTransaction(
      {
        title: title.trim() || 'Untitled Transaction',
        amount: numAmount,
        type,
        packetId,
        packetName: matchedPacket?.name || 'Unassigned',
        category: matchedPacket?.category || 'General',
        merchant: merchant.trim() || 'Self',
        date,
        notes: notes.trim(),
      },
      editingTransaction?.id
    );

    onClose();
    // Reset state
    setNlInput('');
    setTitle('');
    setAmount('');
    setHasParsedPreview(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              {isEditing ? <Edit3 className="w-3.5 h-3.5" /> : <Sparkles className="w-3.5 h-3.5" />}
            </div>
            <h3 className="text-base font-semibold text-white">
              {isEditing ? 'Edit Transaction' : 'Log Transaction'}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {/* Mode switch (hide if editing existing) */}
            {!isEditing && (
              <div className="flex items-center gap-0.5 p-0.5 bg-slate-800 rounded-lg text-xs">
                <button
                  type="button"
                  onClick={() => setMode('ai')}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    mode === 'ai' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  AI Prompt
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('manual');
                    setHasParsedPreview(true);
                  }}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                    mode === 'manual' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Manual
                </button>
              </div>
            )}

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content body */}
        <div className="p-6 space-y-4">
          {mode === 'ai' && !isEditing && (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Natural Language or Receipt Description
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={nlInput}
                    onChange={(e) => setNlInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAIParse();
                      }
                    }}
                    placeholder="e.g., Spent $45.20 at Trader Joe's for dinner essentials"
                    className="w-full bg-slate-800/80 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 outline-none transition-all pr-24"
                  />
                  <button
                    type="button"
                    onClick={() => handleAIParse()}
                    disabled={isParsing || !nlInput.trim()}
                    className="absolute right-1.5 top-1.5 bottom-1.5 px-3 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-800 text-slate-950 disabled:text-slate-500 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    {isParsing ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    <span>Parse</span>
                  </button>
                </div>
              </div>

              {/* Quick Prompt Chips */}
              <div>
                <div className="text-[11px] text-slate-500 mb-1.5">Quick Examples:</div>
                <div className="flex flex-wrap gap-1.5">
                  {QUICK_PROMPTS.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => handleQuickChipClick(prompt)}
                      className="text-xs px-2.5 py-1 rounded-md bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 transition-colors"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>

              {parseError && (
                <div className="text-xs text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded-lg p-2.5">
                  {parseError}
                </div>
              )}
            </div>
          )}

          {/* Form Fields: shown in manual mode, when editing, or once AI has parsed */}
          {(mode === 'manual' || hasParsedPreview || isEditing) && (
            <form onSubmit={handleSubmit} className="space-y-4 pt-2 border-t border-slate-800">
              {/* Type Switcher */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-800/80 rounded-xl">
                <button
                  type="button"
                  onClick={() => setType('expense')}
                  className={`py-1.5 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors ${
                    type === 'expense'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <ArrowDownLeft className="w-3.5 h-3.5 text-rose-400" />
                  Expense Spend
                </button>
                <button
                  type="button"
                  onClick={() => setType('income')}
                  className={`py-1.5 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors ${
                    type === 'income'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                  Income Inflow
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {/* Title */}
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-300 mb-1">Title</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Weekly Grocery Run"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
                  />
                </div>

                {/* Amount */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Amount ({currency})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono tabular-nums focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
                  />
                </div>

                {/* Date */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
                  />
                </div>

                {/* Packet Envelope Assignment */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Assign Envelope
                  </label>
                  <select
                    value={packetId}
                    onChange={(e) => setPacketId(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
                  >
                    {packets.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({currency}{p.allocated - p.spent} left)
                      </option>
                    ))}
                  </select>
                </div>

                {/* Merchant */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Merchant / Source
                  </label>
                  <input
                    type="text"
                    value={merchant}
                    onChange={(e) => setMerchant(e.target.value)}
                    placeholder="e.g. Trader Joe's"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Notes (Optional)</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Shared with roommates, receipt stored"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 outline-none"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-slate-200 bg-slate-800/80 hover:bg-slate-800 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm transition-all flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                  {isEditing ? 'Save Changes' : 'Save & Log to Envelope'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
