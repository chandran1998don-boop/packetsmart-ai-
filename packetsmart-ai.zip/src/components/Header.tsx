import React from 'react';
import { Plus, ArrowLeftRight, Sparkles, MessageSquare, BarChart3, Settings, Eye, EyeOff, Bell } from 'lucide-react';

interface HeaderProps {
  activeTab: 'overview' | 'ledger' | 'charts' | 'audit' | 'chat';
  setActiveTab: (tab: 'overview' | 'ledger' | 'charts' | 'audit' | 'chat') => void;
  onOpenLogModal: () => void;
  onOpenTransferModal: () => void;
  onOpenSettings: () => void;
  privacyMode: boolean;
  onTogglePrivacy: () => void;
  alertCount?: number;
  userAvatarUrl?: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenLogModal,
  onOpenTransferModal,
  onOpenSettings,
  privacyMode,
  onTogglePrivacy,
  alertCount = 0,
  userAvatarUrl = '/src/assets/images/user_avatar_finance_1790574577720.jpg',
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('overview')}
            className="flex items-center gap-2.5 text-left focus:outline-none group"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:bg-emerald-500/20 transition-colors">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg font-bold tracking-tight text-white group-hover:text-emerald-300 transition-colors">
                Packet Smart AI
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'overview'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('ledger')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'ledger'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            Transactions
          </button>
          <button
            onClick={() => setActiveTab('charts')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'charts'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Charts</span>
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'audit'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>Smart Audit</span>
            {alertCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-amber-400" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('chat')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'chat'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
            AI Advisor
          </button>
        </nav>

        {/* Zone 3: Actions + Privacy + Settings */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Privacy Toggle */}
          <button
            onClick={onTogglePrivacy}
            className={`p-2 rounded-lg border text-xs transition-colors ${
              privacyMode
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                : 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
            title={privacyMode ? 'Privacy mode ON (numbers hidden)' : 'Hide balance figures'}
          >
            {privacyMode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>

          {/* Settings Trigger */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-lg border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition-colors"
            title="Budget Settings (Currency, Period, Goal)"
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenTransferModal}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors whitespace-nowrap"
            title="Transfer money between envelopes"
          >
            <ArrowLeftRight className="w-3.5 h-3.5 text-slate-400" />
            Transfer
          </button>

          <button
            onClick={onOpenLogModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm transition-all whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            Log Entry
          </button>

          <div className="pl-1 flex items-center">
            <div className="w-8 h-8 rounded-full ring-1 ring-slate-700 overflow-hidden bg-slate-800 flex items-center justify-center text-xs font-semibold text-slate-300">
              <img
                src={userAvatarUrl}
                alt="User Profile"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Mobile navigation tab strip */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-800/80 px-2 py-1.5 bg-slate-900/95 text-xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-2 py-1 rounded font-medium ${
            activeTab === 'overview' ? 'text-emerald-400 font-semibold' : 'text-slate-400'
          }`}
        >
          Dashboard
        </button>
        <button
          onClick={() => setActiveTab('ledger')}
          className={`px-2 py-1 rounded font-medium ${
            activeTab === 'ledger' ? 'text-emerald-400 font-semibold' : 'text-slate-400'
          }`}
        >
          Ledger
        </button>
        <button
          onClick={() => setActiveTab('charts')}
          className={`px-2 py-1 rounded font-medium ${
            activeTab === 'charts' ? 'text-emerald-400 font-semibold' : 'text-slate-400'
          }`}
        >
          Charts
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`px-2 py-1 rounded font-medium ${
            activeTab === 'audit' ? 'text-emerald-400 font-semibold' : 'text-slate-400'
          }`}
        >
          Audit
        </button>
        <button
          onClick={() => setActiveTab('chat')}
          className={`px-2 py-1 rounded font-medium ${
            activeTab === 'chat' ? 'text-emerald-400 font-semibold' : 'text-slate-400'
          }`}
        >
          AI Advisor
        </button>
      </div>
    </header>
  );
};
