import React, { useState } from 'react';
import {
  Search,
  Filter,
  Download,
  Trash2,
  Edit2,
  Plus,
  Repeat,
  Calendar,
  DollarSign,
  X,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Transaction, Packet } from '../types';

interface TransactionLedgerProps {
  transactions: Transaction[];
  packets: Packet[];
  currency: string;
  privacyMode?: boolean;
  onEditTransaction: (tx: Transaction) => void;
  onDeleteTransaction: (id: string) => void;
  onOpenLogModal: () => void;
}

export const TransactionLedger: React.FC<TransactionLedgerProps> = ({
  transactions,
  packets,
  currency,
  privacyMode = false,
  onEditTransaction,
  onDeleteTransaction,
  onOpenLogModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPacket, setSelectedPacket] = useState('all');
  const [selectedType, setSelectedType] = useState<'all' | 'expense' | 'income'>('all');
  const [datePreset, setDatePreset] = useState<'all' | 'this-month' | 'last-7' | 'last-30' | 'custom'>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [minAmount, setMinAmount] = useState('');
  const [maxAmount, setMaxAmount] = useState('');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'amount-desc' | 'amount-asc'>('date-desc');

  const now = new Date();

  // Filter & Search logic
  const filtered = transactions.filter((tx) => {
    // 1. Text Search
    const matchesSearch =
      tx.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.merchant.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (tx.notes && tx.notes.toLowerCase().includes(searchTerm.toLowerCase()));

    // 2. Envelope / Category
    const matchesPacket = selectedPacket === 'all' || tx.packetId === selectedPacket;

    // 3. Type
    const matchesType = selectedType === 'all' || tx.type === selectedType;

    // 4. Date Filter
    let matchesDate = true;
    const txDate = new Date(tx.date);

    if (datePreset === 'this-month') {
      matchesDate =
        txDate.getFullYear() === now.getFullYear() && txDate.getMonth() === now.getMonth();
    } else if (datePreset === 'last-7') {
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(now.getDate() - 7);
      matchesDate = txDate >= sevenDaysAgo && txDate <= now;
    } else if (datePreset === 'last-30') {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(now.getDate() - 30);
      matchesDate = txDate >= thirtyDaysAgo && txDate <= now;
    } else if (datePreset === 'custom') {
      if (startDate) {
        matchesDate = matchesDate && tx.date >= startDate;
      }
      if (endDate) {
        matchesDate = matchesDate && tx.date <= endDate;
      }
    }

    // 5. Amount Range Filter
    let matchesAmount = true;
    const minVal = parseFloat(minAmount);
    const maxVal = parseFloat(maxAmount);

    if (!isNaN(minVal)) {
      matchesAmount = matchesAmount && tx.amount >= minVal;
    }
    if (!isNaN(maxVal)) {
      matchesAmount = matchesAmount && tx.amount <= maxVal;
    }

    return matchesSearch && matchesPacket && matchesType && matchesDate && matchesAmount;
  });

  // Sort logic
  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'date-desc') return new Date(b.date).getTime() - new Date(a.date).getTime();
    if (sortBy === 'date-asc') return new Date(a.date).getTime() - new Date(b.date).getTime();
    if (sortBy === 'amount-desc') return b.amount - a.amount;
    if (sortBy === 'amount-asc') return a.amount - b.amount;
    return 0;
  });

  const handleExportCSV = () => {
    const headers = ['Date', 'Title', 'Type', 'Amount', 'Envelope', 'Category', 'Merchant', 'Notes'];
    const rows = sorted.map((t) => [
      t.date,
      `"${t.title.replace(/"/g, '""')}"`,
      t.type,
      t.amount.toFixed(2),
      `"${t.packetName.replace(/"/g, '""')}"`,
      `"${t.category.replace(/"/g, '""')}"`,
      `"${t.merchant.replace(/"/g, '""')}"`,
      `"${(t.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `packetsmart-ledger-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const hasActiveFilters =
    searchTerm ||
    selectedPacket !== 'all' ||
    selectedType !== 'all' ||
    datePreset !== 'all' ||
    minAmount ||
    maxAmount;

  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedPacket('all');
    setSelectedType('all');
    setDatePreset('all');
    setStartDate('');
    setEndDate('');
    setMinAmount('');
    setMaxAmount('');
  };

  return (
    <div className="space-y-4">
      {/* Top Filter and Search Bar */}
      <div className="bg-slate-900/60 border border-slate-800 p-3 sm:p-4 rounded-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div className="flex flex-wrap items-center gap-2 flex-1">
            {/* Search */}
            <div className="relative flex-1 min-w-[180px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search merchant, title or notes..."
                className="w-full bg-slate-800/80 border border-slate-700/80 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
              />
            </div>

            {/* Packet Selector */}
            <select
              value={selectedPacket}
              onChange={(e) => setSelectedPacket(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:border-emerald-500"
            >
              <option value="all">All Envelopes</option>
              {packets.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>

            {/* Type Segmented Buttons */}
            <div className="flex items-center gap-0.5 p-0.5 bg-slate-800 rounded-lg text-xs">
              <button
                onClick={() => setSelectedType('all')}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  selectedType === 'all' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setSelectedType('expense')}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  selectedType === 'expense' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Expenses
              </button>
              <button
                onClick={() => setSelectedType('income')}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  selectedType === 'income' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Income
              </button>
            </div>
          </div>

          {/* Toggle Advanced Filters, Sort & Export Actions */}
          <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
            <button
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className={`px-2.5 py-1.5 text-xs rounded-lg border flex items-center gap-1 transition-colors ${
                showAdvancedFilters || datePreset !== 'all' || minAmount || maxAmount
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Filters</span>
              {showAdvancedFilters ? (
                <ChevronUp className="w-3 h-3" />
              ) : (
                <ChevronDown className="w-3 h-3" />
              )}
            </button>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 outline-none focus:border-emerald-500"
            >
              <option value="date-desc">Newest First</option>
              <option value="date-asc">Oldest First</option>
              <option value="amount-desc">Highest Amount</option>
              <option value="amount-asc">Lowest Amount</option>
            </select>

            <button
              onClick={handleExportCSV}
              className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
              title="Export CSV"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Expandable Advanced Filters: Date Range & Amount Filter */}
        {showAdvancedFilters && (
          <div className="pt-3 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3 animate-in fade-in duration-150">
            {/* Date Presets */}
            <div>
              <label className="block text-[11px] font-medium text-slate-400 mb-1 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-slate-400" />
                <span>Date Range</span>
              </label>
              <select
                value={datePreset}
                onChange={(e) => setDatePreset(e.target.value as any)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none focus:border-emerald-500"
              >
                <option value="all">All Dates</option>
                <option value="this-month">This Month</option>
                <option value="last-7">Last 7 Days</option>
                <option value="last-30">Last 30 Days</option>
                <option value="custom">Custom Date Range...</option>
              </select>
            </div>

            {/* Custom Dates if selected */}
            {datePreset === 'custom' && (
              <div className="col-span-1 sm:col-span-2 grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">From Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">To Date</label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            )}

            {/* Amount Range Filter */}
            <div className={datePreset === 'custom' ? 'col-span-1 sm:col-span-3 grid grid-cols-2 gap-2' : 'col-span-1 sm:col-span-2 grid grid-cols-2 gap-2'}>
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1 flex items-center gap-1">
                  <DollarSign className="w-3 h-3 text-slate-400" />
                  <span>Min Amount ({currency})</span>
                </label>
                <input
                  type="number"
                  min="0"
                  step="5"
                  value={minAmount}
                  onChange={(e) => setMinAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono tabular-nums outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1 flex items-center gap-1">
                  <DollarSign className="w-3 h-3 text-slate-400" />
                  <span>Max Amount ({currency})</span>
                </label>
                <input
                  type="number"
                  min="0"
                  step="10"
                  value={maxAmount}
                  onChange={(e) => setMaxAmount(e.target.value)}
                  placeholder="No limit"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono tabular-nums outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {hasActiveFilters && (
              <div className="col-span-full flex justify-end">
                <button
                  onClick={handleResetFilters}
                  className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-medium"
                >
                  <X className="w-3 h-3" />
                  <span>Clear All Filters</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* High-Density Data Grid / Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] font-semibold text-slate-400 bg-slate-900/80 uppercase tracking-wider">
                <th className="py-2.5 px-4">Date</th>
                <th className="py-2.5 px-4">Description</th>
                <th className="py-2.5 px-4">Envelope</th>
                <th className="py-2.5 px-4">Merchant</th>
                <th className="py-2.5 px-4 text-right">Amount</th>
                <th className="py-2.5 px-3 text-center w-20">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {sorted.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    <p className="mb-2">No transactions match your current search and filter criteria.</p>
                    {hasActiveFilters ? (
                      <button
                        onClick={handleResetFilters}
                        className="text-xs text-emerald-400 underline"
                      >
                        Reset filters to view all entries
                      </button>
                    ) : (
                      <button
                        onClick={onOpenLogModal}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                        Log First Transaction
                      </button>
                    )}
                  </td>
                </tr>
              ) : (
                sorted.map((tx) => {
                  const isExpense = tx.type === 'expense';
                  return (
                    <tr
                      key={tx.id}
                      className="hover:bg-slate-800/40 transition-colors h-11 group"
                    >
                      {/* Date */}
                      <td className="py-2 px-4 whitespace-nowrap text-slate-400 font-mono tabular-nums">
                        {tx.date}
                      </td>

                      {/* Description & recurring tag */}
                      <td className="py-2 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-white truncate max-w-[200px] sm:max-w-xs">
                            {tx.title}
                          </span>
                          {tx.isRecurring && (
                            <span
                              title="Recurring automated bill"
                              className="text-slate-500 hover:text-slate-300"
                            >
                              <Repeat className="w-3 h-3" />
                            </span>
                          )}
                        </div>
                        {tx.notes && (
                          <div className="text-[11px] text-slate-500 truncate max-w-[200px] sm:max-w-xs">
                            {tx.notes}
                          </div>
                        )}
                      </td>

                      {/* Envelope */}
                      <td className="py-2 px-4 whitespace-nowrap text-slate-300">
                        <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700/60 text-[11px]">
                          {tx.packetName}
                        </span>
                      </td>

                      {/* Merchant */}
                      <td className="py-2 px-4 whitespace-nowrap text-slate-400">
                        {tx.merchant || '—'}
                      </td>

                      {/* Amount: Right aligned with tabular numbers */}
                      <td className="py-2 px-4 whitespace-nowrap text-right font-mono tabular-nums font-semibold">
                        {privacyMode ? (
                          <span className="text-slate-400">••••</span>
                        ) : (
                          <span
                            className={`inline-flex items-center gap-1 ${
                              isExpense ? 'text-slate-200' : 'text-emerald-400'
                            }`}
                          >
                            {isExpense ? '-' : '+'}
                            {currency}
                            {tx.amount.toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </span>
                        )}
                      </td>

                      {/* Actions: Edit & Delete */}
                      <td className="py-2 px-3 text-center">
                        <div className="flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => onEditTransaction(tx)}
                            className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors"
                            title="Edit transaction"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteTransaction(tx.id)}
                            className="p-1 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded transition-colors"
                            title="Delete transaction"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer info */}
        <div className="px-4 py-2.5 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between">
          <span>Showing {sorted.length} of {transactions.length} total entries</span>
          <span className="font-mono tabular-nums">
            Filtered Net Inflow/Outflow:{' '}
            <span className="text-white font-medium">
              {privacyMode ? (
                '••••'
              ) : (
                <>
                  {currency}
                  {(
                    sorted
                      .filter((t) => t.type === 'income')
                      .reduce((a, b) => a + b.amount, 0) -
                    sorted
                      .filter((t) => t.type === 'expense')
                      .reduce((a, b) => a + b.amount, 0)
                  ).toFixed(2)}
                </>
              )}
            </span>
          </span>
        </div>
      </div>
    </div>
  );
};
