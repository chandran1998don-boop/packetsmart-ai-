import React, { useState, useEffect } from 'react';
import { X, ArrowRight, ArrowLeftRight, Check } from 'lucide-react';
import { Packet, TransferRequest } from '../types';

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  packets: Packet[];
  currency: string;
  defaultFromPacketId?: string;
  onExecuteTransfer: (transfer: TransferRequest) => void;
}

export const TransferModal: React.FC<TransferModalProps> = ({
  isOpen,
  onClose,
  packets,
  currency,
  defaultFromPacketId,
  onExecuteTransfer,
}) => {
  const [fromId, setFromId] = useState(defaultFromPacketId || packets[0]?.id || '');
  const [toId, setToId] = useState(
    packets.find((p) => p.id !== (defaultFromPacketId || packets[0]?.id))?.id || ''
  );
  const [amount, setAmount] = useState<string>('');
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (defaultFromPacketId) {
      setFromId(defaultFromPacketId);
      const other = packets.find((p) => p.id !== defaultFromPacketId);
      if (other) setToId(other.id);
    }
  }, [defaultFromPacketId, packets]);

  if (!isOpen) return null;

  const fromPacket = packets.find((p) => p.id === fromId);
  const toPacket = packets.find((p) => p.id === toId);

  const fromRemaining = fromPacket ? fromPacket.allocated - fromPacket.spent : 0;
  const toRemaining = toPacket ? toPacket.allocated - toPacket.spent : 0;

  const handleQuickAmount = (val: number) => {
    setAmount(String(val));
    setError(null);
  };

  const handleFullSurplus = () => {
    if (fromRemaining > 0) {
      setAmount(String(fromRemaining.toFixed(2)));
      setError(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setError('Please enter a valid positive amount.');
      return;
    }

    if (fromId === toId) {
      setError('Source and destination envelopes must be different.');
      return;
    }

    onExecuteTransfer({
      fromPacketId: fromId,
      toPacketId: toId,
      amount: numAmount,
      note: note.trim() || undefined,
    });

    onClose();
    setAmount('');
    setNote('');
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <ArrowLeftRight className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-base font-semibold text-white">Envelope Transfer</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <p className="text-xs text-slate-400">
            Shift funds from a surplus envelope to cover another envelope without taking on debt.
          </p>

          {/* Transfer Visual Direction */}
          <div className="grid grid-cols-5 gap-2 items-center bg-slate-800/50 border border-slate-800 p-3 rounded-xl">
            {/* From */}
            <div className="col-span-2">
              <label className="block text-[11px] font-medium text-slate-400 mb-1">From Envelope</label>
              <select
                value={fromId}
                onChange={(e) => {
                  setFromId(e.target.value);
                  setError(null);
                }}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none focus:border-emerald-500"
              >
                {packets.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
              <div className="mt-1 text-[11px] text-slate-400 font-mono tabular-nums">
                {currency}{fromRemaining.toFixed(2)} cushion
              </div>
            </div>

            {/* Arrow */}
            <div className="col-span-1 flex justify-center text-slate-500">
              <ArrowRight className="w-4 h-4" />
            </div>

            {/* To */}
            <div className="col-span-2">
              <label className="block text-[11px] font-medium text-slate-400 mb-1">To Envelope</label>
              <select
                value={toId}
                onChange={(e) => {
                  setToId(e.target.value);
                  setError(null);
                }}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none focus:border-emerald-500"
              >
                {packets
                  .filter((p) => p.id !== fromId)
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
              </select>
              <div className="mt-1 text-[11px] text-slate-400 font-mono tabular-nums">
                {currency}{toRemaining.toFixed(2)} current
              </div>
            </div>
          </div>

          {/* Amount input */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Transfer Amount ({currency})
            </label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              required
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                setError(null);
              }}
              placeholder="0.00"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono tabular-nums focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
            />

            {/* Quick helper buttons */}
            <div className="flex items-center gap-1.5 mt-2">
              {[15, 25, 50, 100].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => handleQuickAmount(val)}
                  className="px-2 py-0.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 font-mono transition-colors"
                >
                  +{currency}{val}
                </button>
              ))}
              {fromRemaining > 0 && (
                <button
                  type="button"
                  onClick={handleFullSurplus}
                  className="px-2 py-0.5 text-xs bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30 transition-colors ml-auto"
                >
                  Max Surplus
                </button>
              )}
            </div>
          </div>

          {/* Note */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Reason / Note (Optional)</label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g., Covered weekend dinner from travel fund"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 outline-none"
            />
          </div>

          {error && (
            <div className="text-xs text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded-lg p-2.5">
              {error}
            </div>
          )}

          {/* Buttons */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-slate-200 bg-slate-800/80 hover:bg-slate-800 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm transition-all flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
              Confirm Transfer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
