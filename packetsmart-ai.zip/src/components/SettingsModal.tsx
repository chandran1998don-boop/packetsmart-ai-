import React, { useState } from 'react';
import { X, Check, Globe, DollarSign, Calendar, EyeOff, RotateCcw, Target } from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSaveSettings: (newSettings: AppSettings) => void;
  onResetData: () => void;
}

const CURRENCIES = [
  { code: 'USD', symbol: '$', name: 'US Dollar ($)' },
  { code: 'EUR', symbol: '€', name: 'Euro (€)' },
  { code: 'GBP', symbol: '£', name: 'British Pound (£)' },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee (₹)' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen (¥)' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar (A$)' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar (C$)' },
  { code: 'CHF', symbol: '₣', name: 'Swiss Franc (CHF)' },
  { code: 'BRL', symbol: 'R$', name: 'Brazilian Real (R$)' },
  { code: 'KRW', symbol: '₩', name: 'South Korean Won (₩)' },
];

const LANGUAGES = [
  { code: 'en', name: 'English (US)' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
  { code: 'de', name: 'Deutsch' },
  { code: 'pt', name: 'Português' },
  { code: 'it', name: 'Italiano' },
  { code: 'hi', name: 'हिन्दी (Hindi)' },
  { code: 'ja', name: '日本語 (Japanese)' },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onResetData,
}) => {
  const [currency, setCurrency] = useState(settings.currency);
  const [currencySymbol, setCurrencySymbol] = useState(settings.currencySymbol);
  const [language, setLanguage] = useState(settings.language);
  const [budgetPeriodStartDay, setBudgetPeriodStartDay] = useState(settings.budgetPeriodStartDay || 1);
  const [budgetPeriodType, setBudgetPeriodType] = useState(settings.budgetPeriodType || 'calendar');
  const [monthlyIncome, setMonthlyIncome] = useState(String(settings.monthlyIncome));
  const [userGoal, setUserGoal] = useState(settings.userGoal);
  const [privacyMode, setPrivacyMode] = useState(settings.privacyMode);

  if (!isOpen) return null;

  const handleCurrencyChange = (code: string) => {
    const found = CURRENCIES.find((c) => c.code === code);
    if (found) {
      setCurrency(found.code);
      setCurrencySymbol(found.symbol);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const incomeNum = parseFloat(monthlyIncome);
    onSaveSettings({
      currency,
      currencySymbol,
      language,
      budgetPeriodStartDay: Number(budgetPeriodStartDay) || 1,
      budgetPeriodType,
      monthlyIncome: isNaN(incomeNum) || incomeNum < 0 ? 0 : incomeNum,
      userGoal: userGoal.trim() || 'Save 20% and maintain emergency cushion',
      privacyMode,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">Budget Settings</h3>
              <p className="text-xs text-slate-400">Configure currency, language, and budget cycles</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5">
          {/* Currency Selection */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
              <span>Currency & Symbol</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {CURRENCIES.map((c) => (
                <button
                  type="button"
                  key={c.code}
                  onClick={() => handleCurrencyChange(c.code)}
                  className={`px-3 py-2 text-xs font-medium rounded-xl border text-left flex items-center justify-between transition-colors ${
                    currency === c.code
                      ? 'border-emerald-500 bg-emerald-500/10 text-white'
                      : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <span>{c.name}</span>
                  <span className="font-mono text-emerald-400 font-bold">{c.symbol}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Language Selection */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>Display Language</span>
            </label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:border-emerald-500 outline-none"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.name}
                </option>
              ))}
            </select>
            <span className="text-[11px] text-slate-500 mt-1 block">
              Adjusts number formatting and currency notation.
            </span>
          </div>

          {/* Monthly Budget Period */}
          <div className="border-t border-slate-800 pt-4">
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              <span>Monthly Budget Period & Reset Day</span>
            </label>

            <div className="grid grid-cols-2 gap-3 mb-2">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Period Style</label>
                <select
                  value={budgetPeriodType}
                  onChange={(e) => setBudgetPeriodType(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:border-emerald-500 outline-none"
                >
                  <option value="calendar">Calendar Month (1st - End)</option>
                  <option value="payday">Payday-Based (e.g. 15th)</option>
                  <option value="custom">Custom Cycle Day</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Cycle Starts on Day</label>
                <input
                  type="number"
                  min="1"
                  max="28"
                  value={budgetPeriodStartDay}
                  onChange={(e) => setBudgetPeriodStartDay(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono focus:border-emerald-500 outline-none"
                />
              </div>
            </div>
            <p className="text-[11px] text-slate-500">
              Your budget countdown and progress will calculate relative to day {budgetPeriodStartDay} of each month.
            </p>
          </div>

          {/* Monthly Inflow & Financial Goal */}
          <div className="border-t border-slate-800 pt-4 space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1 flex items-center gap-1.5">
                <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                <span>Monthly Net Income ({currencySymbol})</span>
              </label>
              <input
                type="number"
                min="0"
                step="50"
                value={monthlyIncome}
                onChange={(e) => setMonthlyIncome(e.target.value)}
                placeholder="4850"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono tabular-nums focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-emerald-400" />
                <span>Primary Financial Goal</span>
              </label>
              <input
                type="text"
                value={userGoal}
                onChange={(e) => setUserGoal(e.target.value)}
                placeholder="e.g. Build $10,000 emergency fund and save 25% of net pay"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:border-emerald-500 outline-none"
              />
            </div>
          </div>

          {/* Privacy Mode Toggle */}
          <div className="border-t border-slate-800 pt-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <EyeOff className="w-4 h-4 text-slate-400" />
              <div>
                <div className="text-xs font-medium text-white">Privacy Mode</div>
                <div className="text-[11px] text-slate-400">Mask balance numbers for browsing in public</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={privacyMode}
                onChange={(e) => setPrivacyMode(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
            </label>
          </div>

          {/* Privacy & Professional Advice Disclaimer Notice */}
          <div className="border-t border-slate-800 pt-4 p-3 bg-slate-800/40 border border-slate-800 rounded-xl text-[11px] text-slate-400 leading-relaxed">
            <span className="font-semibold text-slate-300">Privacy & Financial Disclaimer: </span>
            Packet Smart AI stores your data locally in your browser. All AI suggestions are for informational and budgeting educational purposes only, and do not constitute certified professional financial, investment, or legal advice.
          </div>

          {/* Reset Data Button */}
          <div className="pt-2 flex items-center justify-between text-xs">
            <button
              type="button"
              onClick={() => {
                if (confirm('Are you sure you want to reset all packets and transactions to sample data?')) {
                  onResetData();
                  onClose();
                }
              }}
              className="text-rose-400 hover:text-rose-300 flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Sample Data</span>
            </button>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-slate-200 bg-slate-800/80 hover:bg-slate-800 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm transition-all flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
              Save Preferences
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
