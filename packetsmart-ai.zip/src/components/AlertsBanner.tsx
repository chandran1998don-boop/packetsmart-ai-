import React, { useState } from 'react';
import { AlertTriangle, AlertCircle, ArrowRight, ArrowLeftRight, ChevronDown, ChevronUp, Bell } from 'lucide-react';
import { Packet, BudgetAlert } from '../types';

interface AlertsBannerProps {
  packets: Packet[];
  currencySymbol: string;
  onOpenTransfer: (fromPacketId?: string, toPacketId?: string) => void;
  onEditLimit: (packet: Packet) => void;
}

export const AlertsBanner: React.FC<AlertsBannerProps> = ({
  packets,
  currencySymbol,
  onOpenTransfer,
  onEditLimit,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Compute alerts
  const alerts: BudgetAlert[] = [];

  packets.forEach((p) => {
    if (p.allocated <= 0) return;
    const pct = (p.spent / p.allocated) * 100;
    if (p.spent > p.allocated) {
      alerts.push({
        id: `over-${p.id}`,
        type: 'danger',
        packetId: p.id,
        packetName: p.name,
        title: `${p.name} is Over Budget!`,
        message: `Exceeded allocation by ${currencySymbol}${(p.spent - p.allocated).toFixed(2)} (${pct.toFixed(0)}% used).`,
        percentUsed: pct,
        amountOver: p.spent - p.allocated,
      });
    } else if (pct >= 80) {
      alerts.push({
        id: `warn-${p.id}`,
        type: 'warning',
        packetId: p.id,
        packetName: p.name,
        title: `${p.name} is Near Capacity`,
        message: `At ${pct.toFixed(0)}% of limit with only ${currencySymbol}${(p.allocated - p.spent).toFixed(2)} remaining cushion.`,
        percentUsed: pct,
        amountRemaining: p.allocated - p.spent,
      });
    }
  });

  if (alerts.length === 0) return null;

  const dangerAlerts = alerts.filter((a) => a.type === 'danger');
  const warningAlerts = alerts.filter((a) => a.type === 'warning');
  const primaryAlert = dangerAlerts[0] || warningAlerts[0];

  return (
    <div className="mb-6 rounded-2xl border border-amber-500/30 bg-gradient-to-r from-amber-500/10 via-slate-900 to-slate-900 overflow-hidden shadow-lg">
      <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start sm:items-center gap-3">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
              dangerAlerts.length > 0
                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
            }`}
          >
            {dangerAlerts.length > 0 ? (
              <AlertTriangle className="w-4 h-4" />
            ) : (
              <Bell className="w-4 h-4" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white tracking-wide uppercase">
                {dangerAlerts.length > 0 ? 'Budget Overdraft Alert' : 'Budget Warning Alert'}
              </span>
              <span className="px-2 py-0.5 text-[10px] font-semibold bg-amber-500/20 text-amber-300 rounded-full border border-amber-500/30 font-mono">
                {alerts.length} {alerts.length === 1 ? 'envelope alert' : 'envelope alerts'}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              <strong className="text-white">{primaryAlert.packetName}:</strong> {primaryAlert.message}
            </p>
          </div>
        </div>

        {/* Quick action buttons */}
        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
          <button
            onClick={() => onOpenTransfer('fun-travel', primaryAlert.packetId)}
            className="px-3 py-1.5 text-xs font-semibold bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            <span>Transfer Cushion</span>
          </button>

          {alerts.length > 1 && (
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg flex items-center gap-1 transition-colors"
            >
              <span>{isExpanded ? 'Hide All' : `View All (${alerts.length})`}</span>
              {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
          )}
        </div>
      </div>

      {/* Expandable list of all alerts */}
      {isExpanded && alerts.length > 1 && (
        <div className="border-t border-slate-800/80 bg-slate-950/40 p-4 space-y-2">
          {alerts.map((alert) => {
            const isDanger = alert.type === 'danger';
            const targetPacket = packets.find((p) => p.id === alert.packetId);

            return (
              <div
                key={alert.id}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      isDanger ? 'bg-rose-400' : 'bg-amber-400'
                    }`}
                  />
                  <div>
                    <span className="font-semibold text-white mr-2">{alert.packetName}</span>
                    <span className="text-slate-400">{alert.message}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {targetPacket && (
                    <button
                      onClick={() => onEditLimit(targetPacket)}
                      className="text-[11px] text-slate-400 hover:text-white underline"
                    >
                      Adjust Limit
                    </button>
                  )}
                  <button
                    onClick={() => onOpenTransfer(undefined, alert.packetId)}
                    className="px-2 py-1 text-[11px] bg-slate-800 hover:bg-slate-700 text-emerald-400 rounded border border-slate-700 transition-colors"
                  >
                    Transfer
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
