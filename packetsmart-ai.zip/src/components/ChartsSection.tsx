import React, { useState } from 'react';
import { BarChart3, PieChart, TrendingUp, Calendar, AlertCircle } from 'lucide-react';
import { Packet, Transaction } from '../types';

interface ChartsSectionProps {
  packets: Packet[];
  transactions: Transaction[];
  currencySymbol: string;
  monthlyIncome: number;
  privacyMode?: boolean;
}

export const ChartsSection: React.FC<ChartsSectionProps> = ({
  packets,
  transactions,
  currencySymbol,
  monthlyIncome,
  privacyMode = false,
}) => {
  const [activeChart, setActiveChart] = useState<'trends' | 'categories' | 'comparison'>('trends');
  const [hoveredPoint, setHoveredPoint] = useState<{ day: number; amount: number; count: number } | null>(null);

  const formatAmount = (val: number) => {
    if (privacyMode) return '••••';
    return `${currencySymbol}${val.toLocaleString(undefined, {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })}`;
  };

  // 1. Prepare Daily Spending Trends for current month (Days 1 to 30)
  const now = new Date();
  const currentMonth = (now.getMonth() + 1).toString().padStart(2, '0');
  const currentYear = now.getFullYear();

  const daysInMonth = new Date(currentYear, now.getMonth() + 1, 0).getDate();
  const dailySpend: Record<number, { amount: number; count: number }> = {};
  for (let d = 1; d <= daysInMonth; d++) {
    dailySpend[d] = { amount: 0, count: 0 };
  }

  transactions.forEach((tx) => {
    if (tx.type === 'expense') {
      const parts = tx.date.split('-');
      if (parts.length === 3) {
        const day = parseInt(parts[2], 10);
        if (day >= 1 && day <= daysInMonth) {
          dailySpend[day].amount += tx.amount;
          dailySpend[day].count += 1;
        }
      }
    }
  });

  const trendData = Object.entries(dailySpend).map(([dayStr, data]) => ({
    day: Number(dayStr),
    amount: data.amount,
    count: data.count,
  }));

  const maxDaily = Math.max(...trendData.map((d) => d.amount), 50);
  const totalMonthlySpend = packets.reduce((acc, p) => acc + p.spent, 0);
  const totalAllocated = packets.reduce((acc, p) => acc + p.allocated, 0);

  // 2. Prepare Category Breakdown
  const categorySpendList = packets
    .filter((p) => p.spent > 0)
    .sort((a, b) => b.spent - a.spent);

  // 3. Prepare Comparison (Allocated vs Spent)
  const sortedByAllocated = [...packets].sort((a, b) => b.allocated - a.allocated);

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 sm:p-6 space-y-5">
      {/* Top Segmented Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>Spending Analytics & Trends</span>
          </h3>
          <p className="text-xs text-slate-400">
            Interactive visual comparisons of daily velocity, category share, and envelope limits
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-800/90 rounded-xl self-start sm:self-auto border border-slate-700/60 text-xs">
          <button
            onClick={() => setActiveChart('trends')}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
              activeChart === 'trends'
                ? 'bg-slate-700 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Daily Velocity</span>
          </button>
          <button
            onClick={() => setActiveChart('categories')}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
              activeChart === 'categories'
                ? 'bg-slate-700 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PieChart className="w-3.5 h-3.5" />
            <span>Category Share</span>
          </button>
          <button
            onClick={() => setActiveChart('comparison')}
            className={`px-3 py-1.5 font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
              activeChart === 'comparison'
                ? 'bg-slate-700 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Budget vs Actual</span>
          </button>
        </div>
      </div>

      {/* 1. Daily Spending Velocity Bar Chart */}
      {activeChart === 'trends' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Daily Outflows Across Month</span>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
                Active Days
              </span>
              <span className="font-mono tabular-nums text-slate-300">
                Total Month Spend: <strong className="text-white">{formatAmount(totalMonthlySpend)}</strong>
              </span>
            </div>
          </div>

          {/* Interactive SVG Bar Chart */}
          <div className="relative h-48 sm:h-56 w-full flex items-end gap-1 sm:gap-1.5 pt-6 pb-6 px-1 border-b border-slate-800">
            {trendData.map((d) => {
              const heightPct = maxDaily > 0 ? (d.amount / maxDaily) * 100 : 0;
              const hasSpend = d.amount > 0;
              const isHovered = hoveredPoint?.day === d.day;

              return (
                <div
                  key={d.day}
                  onMouseEnter={() => setHoveredPoint(d)}
                  onMouseLeave={() => setHoveredPoint(null)}
                  className="flex-1 flex flex-col items-center justify-end h-full group relative cursor-pointer"
                >
                  {/* Tooltip on hover */}
                  {isHovered && (
                    <div className="absolute -top-10 z-20 bg-slate-800 text-white border border-slate-700 px-2 py-1 rounded-md text-[11px] font-mono whitespace-nowrap shadow-xl pointer-events-none">
                      Day {d.day}: {formatAmount(d.amount)} ({d.count} tx)
                    </div>
                  )}

                  {/* The bar */}
                  <div
                    style={{ height: `${Math.max(hasSpend ? 8 : 2, heightPct)}%` }}
                    className={`w-full rounded-t-sm transition-all duration-200 ${
                      isHovered
                        ? 'bg-emerald-300'
                        : hasSpend
                        ? d.amount > 200
                          ? 'bg-amber-400'
                          : 'bg-emerald-500/80 hover:bg-emerald-400'
                        : 'bg-slate-800/60'
                    }`}
                  />
                  {/* Day number underneath */}
                  <span className="absolute -bottom-5 text-[10px] text-slate-500 font-mono">
                    {d.day % 5 === 0 || d.day === 1 ? d.day : ''}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
            <span>Day 1</span>
            <span>Day 15</span>
            <span>Day {daysInMonth}</span>
          </div>
        </div>
      )}

      {/* 2. Category Share Breakdown */}
      {activeChart === 'categories' && (
        <div className="space-y-4">
          <div className="text-xs text-slate-400">
            Spending distribution across your {categorySpendList.length} active spending envelopes:
          </div>

          {/* Horizontal multi-color segmented proportional bar */}
          <div className="w-full h-4 rounded-full overflow-hidden bg-slate-800 flex shadow-inner">
            {categorySpendList.map((packet) => {
              const pct = totalMonthlySpend > 0 ? (packet.spent / totalMonthlySpend) * 100 : 0;
              return (
                <div
                  key={packet.id}
                  style={{
                    width: `${pct}%`,
                    backgroundColor: packet.color,
                  }}
                  title={`${packet.name}: ${formatAmount(packet.spent)} (${pct.toFixed(1)}%)`}
                  className="h-full hover:opacity-90 transition-opacity"
                />
              );
            })}
          </div>

          {/* Cards for each category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
            {categorySpendList.map((packet) => {
              const pct = totalMonthlySpend > 0 ? (packet.spent / totalMonthlySpend) * 100 : 0;
              return (
                <div
                  key={packet.id}
                  className="bg-slate-800/40 border border-slate-800 rounded-xl p-3 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: packet.color }}
                      />
                      <span className="text-xs font-semibold text-white truncate max-w-[130px]">
                        {packet.name}
                      </span>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-400">
                      {pct.toFixed(0)}%
                    </span>
                  </div>

                  <div className="flex items-baseline justify-between text-xs text-slate-400 font-mono tabular-nums">
                    <span>Spent:</span>
                    <span className="text-slate-200 font-medium">{formatAmount(packet.spent)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. Budget vs Actual Comparison */}
      {activeChart === 'comparison' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Envelope Allocation vs Actual Month Spend</span>
            <div className="flex items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-600 inline-block" />
                Allocated Limit
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
                Actual Spent
              </span>
            </div>
          </div>

          <div className="space-y-3">
            {sortedByAllocated.map((packet) => {
              const pct = packet.allocated > 0 ? (packet.spent / packet.allocated) * 100 : 0;
              const isOver = packet.spent > packet.allocated;

              return (
                <div key={packet.id} className="bg-slate-800/30 border border-slate-800/80 rounded-xl p-3">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: packet.color }}
                      />
                      <span className="font-semibold text-white">{packet.name}</span>
                      <span className="text-[11px] text-slate-500 font-mono tabular-nums">
                        ({pct.toFixed(0)}%)
                      </span>
                    </div>

                    <div className="text-xs font-mono tabular-nums">
                      <span className={isOver ? 'text-rose-400 font-semibold' : 'text-slate-200'}>
                        {formatAmount(packet.spent)}
                      </span>
                      <span className="text-slate-500 mx-1">/</span>
                      <span className="text-slate-400">{formatAmount(packet.allocated)}</span>
                    </div>
                  </div>

                  {/* Dual bar or progress bar */}
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
                      className={`h-full transition-all duration-300 ${
                        isOver
                          ? 'bg-rose-500'
                          : pct >= 80
                          ? 'bg-amber-400'
                          : 'bg-emerald-400'
                      }`}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
