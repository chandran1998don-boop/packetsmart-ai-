import React, { useState, useEffect } from 'react';
import { X, Check, Trash2 } from 'lucide-react';
import { Packet } from '../types';
import { IconResolver } from './IconResolver';

interface EditPacketModalProps {
  isOpen: boolean;
  onClose: () => void;
  packet: Packet | null; // null if creating a new packet
  currency: string;
  onSavePacket: (packet: Packet) => void;
  onDeletePacket?: (packetId: string) => void;
}

const AVAILABLE_ICONS = [
  'Home',
  'ShoppingCart',
  'Utensils',
  'Car',
  'Tv',
  'Activity',
  'TrendingUp',
  'Compass',
  'Coffee',
  'Briefcase',
  'Gift',
  'Zap',
  'Shield',
];

const AVAILABLE_COLORS = [
  '#3b82f6', // blue
  '#10b981', // emerald
  '#f59e0b', // amber
  '#ef4444', // red
  '#8b5cf6', // purple
  '#ec4899', // pink
  '#06b6d4', // cyan
  '#14b8a6', // teal
  '#6366f1', // indigo
];

export const EditPacketModal: React.FC<EditPacketModalProps> = ({
  isOpen,
  onClose,
  packet,
  currency,
  onSavePacket,
  onDeletePacket,
}) => {
  const isNew = !packet;

  const [name, setName] = useState('');
  const [category, setCategory] = useState('Lifestyle');
  const [allocated, setAllocated] = useState('200');
  const [icon, setIcon] = useState('Compass');
  const [color, setColor] = useState('#10b981');
  const [description, setDescription] = useState('');
  const [isEssential, setIsEssential] = useState(false);

  useEffect(() => {
    if (packet) {
      setName(packet.name);
      setCategory(packet.category);
      setAllocated(String(packet.allocated));
      setIcon(packet.icon);
      setColor(packet.color);
      setDescription(packet.description);
      setIsEssential(Boolean(packet.isEssential));
    } else {
      setName('');
      setCategory('Lifestyle');
      setAllocated('250');
      setIcon('Compass');
      setColor('#10b981');
      setDescription('');
      setIsEssential(false);
    }
  }, [packet, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(allocated);
    if (isNaN(num) || num < 0) return;

    onSavePacket({
      id: packet ? packet.id : `packet-${Date.now()}`,
      name: name.trim() || 'Custom Envelope',
      category: category.trim() || 'General',
      allocated: num,
      spent: packet ? packet.spent : 0,
      icon,
      color,
      description: description.trim() || 'Custom budget envelope',
      isEssential,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <h3 className="text-base font-semibold text-white">
            {isNew ? 'Create New Envelope' : `Edit "${packet?.name}"`}
          </h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Envelope Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Pet Care & Vet"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-emerald-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Monthly Cap ({currency})
              </label>
              <input
                type="number"
                min="0"
                step="10"
                required
                value={allocated}
                onChange={(e) => setAllocated(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono tabular-nums focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:border-emerald-500 outline-none"
              >
                <option value="Essentials">Essentials</option>
                <option value="Lifestyle">Lifestyle</option>
                <option value="Wealth">Wealth & Savings</option>
                <option value="Personal">Personal</option>
              </select>
            </div>
          </div>

          {/* Icon Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Icon</label>
            <div className="flex flex-wrap gap-1.5 p-2 bg-slate-800/60 rounded-xl border border-slate-800">
              {AVAILABLE_ICONS.map((ic) => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setIcon(ic)}
                  className={`p-2 rounded-lg transition-colors ${
                    icon === ic
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'text-slate-400 hover:text-white hover:bg-slate-700/60'
                  }`}
                >
                  <IconResolver name={ic} className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>

          {/* Color Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Accent Color</label>
            <div className="flex items-center gap-2">
              {AVAILABLE_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`w-6 h-6 rounded-full transition-transform ${
                    color === c ? 'scale-125 ring-2 ring-white ring-offset-2 ring-offset-slate-900' : 'hover:scale-110'
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Description / Memo</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Food, vaccinations, toys and insurance"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 outline-none"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="essential-check"
              checked={isEssential}
              onChange={(e) => setIsEssential(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700 text-emerald-500 focus:ring-emerald-500"
            />
            <label htmlFor="essential-check" className="text-xs text-slate-300 cursor-pointer">
              Mark as non-negotiable Essential need
            </label>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            {!isNew && onDeletePacket ? (
              <button
                type="button"
                onClick={() => {
                  if (confirm(`Delete the envelope "${packet?.name}"?`)) {
                    onDeletePacket(packet!.id);
                    onClose();
                  }
                }}
                className="p-2 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-lg transition-colors"
                title="Delete Envelope"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            ) : <div />}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-400 hover:text-slate-200 bg-slate-800 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm transition-all flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                {isNew ? 'Create Envelope' : 'Save Changes'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
