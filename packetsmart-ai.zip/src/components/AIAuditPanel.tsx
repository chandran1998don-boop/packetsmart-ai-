import React, { useState } from 'react';
import {
  Sparkles,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  ArrowRight,
  ShieldCheck,
  PiggyBank,
  Zap,
} from 'lucide-react';
import { AIAuditResult, BudgetProfile, Packet, Transaction } from '../types';

interface AIAuditPanelProps {
  audit: AIAuditResult;
  profile: BudgetProfile;
  packets: Packet[];
  transactions: Transaction[];
  onApplyRecommendation: (recommendation: any) => void;
  onUpdateAudit: (newAudit: AIAuditResult) => void;
}

export const AIAuditPanel: React.FC<AIAuditPanelProps> = ({
  audit,
  profile,
  packets,
  transactions,
  onApplyRecommendation,
  onUpdateAudit,
}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const { currency, monthlyIncome } = profile;
  const currentSpend = packets.reduce((acc, p) => acc + p.spent, 0);

  const handleRunAudit = async () => {
    setIsRunning(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/ai/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          packets: packets.map((p) => ({
            id: p.id,
            name: p.name,
            category: p.category,
            allocated: p.allocated,
            spent: p.spent,
            remaining: p.allocated - p.spent,
          })),
          monthlyIncome,
          currentSpend,
          transactions: transactions.slice(0, 15),
          currency,
        }),
      });

      if (!res.ok) {
        throw new Error('AI Audit generation failed');
      }

      const data = await res.json();
      onUpdateAudit(data);
    } catch (err: any) {
      setErrorMessage(err.message || 'Unable to complete AI audit. Please try again.');
    } finally {
      setIsRunning(false);
    }
  };

  const scoreColor =
    audit.overallHealthScore >= 80
      ? 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10'
      : audit.overallHealthScore >= 65
      ? 'text-amber-400 border-amber-500/30 bg-amber-500/10'
      : 'text-rose-400 border-rose-500/30 bg-rose-500/10';

  return (
    <div className="space-y-6">
      {/* Top Banner: Auditor Header with Trigger Button */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight">
              PacketSmart AI Budget Auditor
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-400">
            Real-time behavioral audit scanning envelope burn velocity, savings rate, and hidden money leaks.
          </p>
        </div>

        <button
          onClick={handleRunAudit}
          disabled={isRunning}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-400 hover:bg-emerald-300 disabled:bg-slate-800 text-slate-950 disabled:text-slate-500 rounded-xl text-xs sm:text-sm font-semibold shadow-sm transition-all whitespace-nowrap self-start sm:self-auto"
        >
          <RefreshCw className={`w-4 h-4 ${isRunning ? 'animate-spin' : ''}`} />
          {isRunning ? 'Auditing Envelopes...' : 'Run Deep AI Health Check'}
        </button>
      </div>

      {errorMessage && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs rounded-xl">
          {errorMessage}
        </div>
      )}

      {/* Main Score & Forecast Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Score Card */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="text-xs font-medium text-slate-400 mb-3 flex items-center justify-between">
              <span>Financial Health Index</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>

            <div className="flex items-center gap-4">
              <div
                className={`w-16 h-16 rounded-2xl border flex flex-col items-center justify-center font-mono font-bold text-2xl ${scoreColor}`}
              >
                {audit.overallHealthScore}
                <span className="text-[10px] font-sans font-normal opacity-80">/100</span>
              </div>
              <div>
                <div className="text-sm font-semibold text-white">{audit.healthRating} Condition</div>
                <div className="text-xs text-slate-400 mt-0.5">
                  Savings Rate: <span className="font-mono text-emerald-400 font-semibold">{audit.savingsRatePercent}%</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 text-xs text-slate-400">
            Projected monthly wealth retained: <span className="font-mono text-white font-semibold">{currency}{audit.monthlySavingsProjected.toLocaleString()}</span>
          </div>
        </div>

        {/* Headline & Takeaway */}
        <div className="md:col-span-2 bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="text-xs font-medium text-slate-400 mb-2 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Auditor Executive Takeaway</span>
            </div>
            <h3 className="text-base sm:text-lg font-semibold text-white mb-3">
              "{audit.summaryHeadline}"
            </h3>
            <div className="text-xs text-slate-400 leading-relaxed bg-slate-800/40 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-300 font-medium">Cashflow Outlook: </span>
              {audit.cashflowForecast}
            </div>
          </div>

          <div className="mt-3 text-[11px] text-slate-500">
            Refreshed using your live envelopes & recent transaction cadence
          </div>
        </div>
      </div>

      {/* Two Column: Key Insights & Leak Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Key Quantitative Insights */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 mb-3.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Key Quantitative Observations</span>
          </div>
          <ul className="space-y-2.5 text-xs text-slate-400">
            {audit.keyInsights.map((insight, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-emerald-400/80 font-mono mt-0.5">·</span>
                <span className="leading-relaxed">{insight}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Money Leak Alerts */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-3.5">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Detected Money Leaks</span>
            </div>
            <span className="text-[11px] text-slate-400">High burn warnings</span>
          </div>

          <div className="space-y-3">
            {audit.leakAlerts.map((leak, idx) => (
              <div
                key={idx}
                className="bg-amber-500/5 border border-amber-500/20 rounded-lg p-3 text-xs"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-amber-300">{leak.title}</span>
                  <span className="font-mono font-bold text-amber-400">
                    -{currency}{leak.estimatedMonthlyLeak}/mo
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mb-1">{leak.packetName}</div>
                <p className="text-slate-400 leading-relaxed text-[11px]">{leak.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Actionable Recommendations */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>Prioritized Envelope Optimization Actions</span>
          </div>
          <span className="text-[11px] text-slate-400">Impact-ranked</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {audit.recommendations.map((rec, idx) => {
            const priorityBadge =
              rec.priority === 'high'
                ? 'text-rose-400 bg-rose-500/10'
                : rec.priority === 'medium'
                ? 'text-amber-400 bg-amber-500/10'
                : 'text-emerald-400 bg-emerald-500/10';

            return (
              <div
                key={idx}
                className="bg-slate-800/40 border border-slate-800 hover:border-slate-700/80 rounded-xl p-4 flex flex-col justify-between transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between text-[11px] mb-2">
                    <span className="text-slate-400">{rec.category}</span>
                    <span className={`px-2 py-0.5 rounded font-medium capitalize ${priorityBadge}`}>
                      {rec.priority} Priority
                    </span>
                  </div>

                  <h4 className="text-sm font-semibold text-white mb-1.5 leading-snug">
                    {rec.title}
                  </h4>

                  <div className="text-xs text-emerald-400 font-medium mb-2 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    <span>{rec.impact}</span>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed mb-4">
                    {rec.actionPlan}
                  </p>
                </div>

                <button
                  onClick={() => onApplyRecommendation(rec)}
                  className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 hover:text-white rounded-lg transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>Apply Recommendation</span>
                  <ArrowRight className="w-3 h-3 text-slate-400" />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
