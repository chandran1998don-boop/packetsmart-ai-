import React from 'react';
import {
  Home,
  ShoppingCart,
  Utensils,
  Car,
  Tv,
  Activity,
  TrendingUp,
  Compass,
  Briefcase,
  Gift,
  Coffee,
  Zap,
  Shield,
  HelpCircle,
} from 'lucide-react';

const ICON_MAP: Record<string, React.ElementType> = {
  Home,
  ShoppingCart,
  Utensils,
  Car,
  Tv,
  Activity,
  TrendingUp,
  Compass,
  Briefcase,
  Gift,
  Coffee,
  Zap,
  Shield,
};

interface IconResolverProps {
  name: string;
  className?: string;
  style?: React.CSSProperties;
}

export const IconResolver: React.FC<IconResolverProps> = ({ name, className = 'w-5 h-5', style }) => {
  const Component = ICON_MAP[name] || HelpCircle;
  return <Component className={className} style={style} />;
};
