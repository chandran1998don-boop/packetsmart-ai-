import React, { useState } from 'react';
import { Plus, ArrowLeftRight, Settings2, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Packet } from '../types';
import { IconResolver } from './IconResolver';

interface PacketsGridProps {
  packets: Packet[];
  currency: string;
  privacyMode?: boolean;
  onLogToPacket: (packetId: string) => void;
  onTransferFromPacket: (packetId: string) => void;
  onEditPacket: (packet: Packet) => void;
  onAddNewPacket: () => void;
}

export const PacketsGrid: React.FC<PacketsGridProps> = ({
  packets,
  currency,
  privacyMode = false,
  onLogToPacket,
  onTransferFromPacket,
  onEditPacket,
  onAddNewPacket,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const categories = ['all', ...Array.from(new Set(packets.map((p) => p.category)))];

  const filteredPackets =
    filterCategory === 'all'
      ? packets
      : packets.filter((p) => p.category.toLowerCase() === filterCategory.toLowerCase());

  return (
    <div className="space-y-4">
      {/* Category filter segmented control + Add Packet Button */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors capitalize ${
                filterCategory === cat
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat === 'all' ? 'All Envelopes' : cat}
            </button>
          ))}
        </div>

        <button
          onClick={onAddNewPacket}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-800/80 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
        >
          <Plus className="w-3.5 h-3.5 text-emerald-400" />
          New Envelope
        </button>
      </div>

      {/* Grid of Envelope Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredPackets.map((packet) => {
          const percentUsed = packet.allocated > 0 ? (packet.spent / packet.allocated) * 100 : 0;
          const remaining = packet.allocated - packet.spent;
          const isOverspent = remaining < 0;
          const isCaution = percentUsed >= 80 && !isOverspent;

          // Progress bar color determination
          let progressColor = 'bg-emerald-500';
          let textColor = 'text-emerald-400';
          if (isOverspent) {
            progressColor = 'bg-rose-500';
            textColor = 'text-rose-400';
          } else if (isCaution) {
            progressColor = 'bg-amber-500';
            textColor = 'text-amber-400';
          }

          return (
            <div
              key={packet.id}
              className="bg-slate-900/60 border border-slate-800 hover:border-slate-700/80 rounded-xl p-4 flex flex-col justify-between transition-all duration-200 group"
            >
              <div>
                {/* Header: Icon, Category metadata and settings */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-white"
                      style={{ backgroundColor: `${packet.color}20`, color: packet.color }}
                    >
                      <IconResolver name={packet.icon} className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-white group-hover:text-emerald-300 transition-colors">
                        {packet.name}
                      </h4>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                        <span>{packet.category}</span>
                        {packet.isEssential && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-slate-400 font-medium">Essential</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onEditPacket(packet)}
                    className="text-slate-500 hover:text-slate-300 p-1 rounded hover:bg-slate-800 transition-colors"
                    title="Edit Envelope Allocation"
                  >
                    <Settings2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-400 line-clamp-1 mb-3.5">
                  {packet.description}
                </p>

                {/* Financial Figures */}
                <div className="flex items-baseline justify-between mb-1.5">
                  <div>
                    <span className="text-xs text-slate-400">Remaining</span>
                    <div
                      className={`text-lg font-bold font-mono tabular-nums ${
                        isOverspent ? 'text-rose-400' : 'text-white'
                      }`}
                    >
                      {privacyMode ? (
                        '••••'
                      ) : (
                        <>
                          {isOverspent ? '-' : ''}
                          {currency}
                          {Math.abs(remaining).toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </>
                      )}
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-slate-400">Limit</span>
                    <div className="text-xs font-semibold text-slate-300 font-mono tabular-nums">
                      {privacyMode ? (
                        '••••'
                      ) : (
                        <>
                          {currency}
                          {packet.allocated.toLocaleString()}
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden mb-2">
                  <div
                    className={`h-full transition-all duration-300 ${progressColor}`}
                    style={{ width: `${Math.min(100, Math.max(0, percentUsed))}%` }}
                  />
                </div>

                {/* Footer status text */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-3 font-mono tabular-nums">
                  <span className="flex items-center gap-1">
                    {isOverspent ? (
                      <span className="text-rose-400 flex items-center gap-1 font-semibold">
                        <AlertTriangle className="w-3 h-3" /> Over budget
                      </span>
                    ) : isCaution ? (
                      <span className="text-amber-400 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> High burn
                      </span>
                    ) : (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> On track
                      </span>
                    )}
                  </span>
                  <span>{percentUsed.toFixed(0)}% used</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/80">
                <button
                  onClick={() => onLogToPacket(packet.id)}
                  className="px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-800 rounded-lg flex items-center justify-center gap-1 transition-colors"
                >
                  <Plus className="w-3 h-3 text-emerald-400" />
                  Log Spend
                </button>
                <button
                  onClick={() => onTransferFromPacket(packet.id)}
                  className="px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-800 rounded-lg flex items-center justify-center gap-1 transition-colors"
                >
                  <ArrowLeftRight className="w-3 h-3 text-slate-400" />
                  Transfer
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
